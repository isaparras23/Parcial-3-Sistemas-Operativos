# Resultados de la ejecución de pruebas

Salidas reales de la ejecución en la máquina virtual de validación (QEMU, x86_64, 2 CPU, 3 GB de RAM). La corrida completa (pruebas, eBPF y benchmark) usó el kernel Ubuntu 6.17.0-42-generic y se generó con:

```bash
./qemu/run_in_qemu.sh /boot/vmlinuz-6.17.0-42-generic /usr/src/linux-headers-6.17.0-42-generic
```

## Resumen: 90 de 90 verificaciones

| Programa | Verificaciones | Resultado |
|---|---|---|
| `tests/test_semantica` | 16 | 16 PASS, 0 FAIL |
| `tests/test_policy` | 33 | 33 PASS, 0 FAIL |
| `tests/test_vault` | 32 | 32 PASS, 0 FAIL |
| `tests/test_wx` | 7 | 7 PASS, 0 FAIL |
| `tests/test_race` | 2 | 2 PASS, 0 FAIL |
| Total | 90 | 90 PASS, 0 FAIL |

## Compatibilidad comprobada

| Kernel | Compilación | Batería de pruebas |
|---|---|---|
| 5.15.0-203-generic (Ubuntu 22.04) | `make` con código 0, sin diagnósticos del compilador (`compilacion_kernel_5.15.0-203.log`) | 90/90 (`pruebas_codigo_final_kernel_5.15.0-203.log`) |
| 6.8.0-147-generic (Ubuntu 24.04) | `make` con código 0, sin advertencias (`compilacion_kernel_6.8.0-147.log`) | No ejecutada |
| 6.17.0-42-generic (Ubuntu 24.04 HWE) | `make` con código 0, sin advertencias (`compilacion_kernel_6.17.0-42.log`) | 90/90 (`pruebas_codigo_final_kernel_6.17.0-42.log` y `pruebas_90_de_90.log`) |

La primera compilación contra 5.15 falló y así detectamos dos problemas de portabilidad que en 6.x no se veían: una variable declarada dentro de un `for` (antes de 5.18 el kernel compila en modo gnu89) y la falta de `#include <linux/mm.h>` y `<linux/slab.h>` en `mmguard_audit.c` (en 6.x llegaban de forma indirecta). Después de corregirlos se repitió la batería en 5.15 y en 6.17 con el código final; esos son los archivos `pruebas_codigo_final_kernel_*.log`. `pruebas_90_de_90.log` y el resto de archivos (eBPF, benchmark, estado final) son de la corrida completa anterior a esa corrección, que solo cambió la declaración de una variable y dos `#include`.

Se corrió con `MODE=tests` (solo la batería):

```bash
MODE=tests KCC=x86_64-linux-gnu-gcc-11 ./qemu/run_in_qemu.sh /boot/vmlinuz-5.15.0-203-generic /usr/src/linux-headers-5.15.0-203-generic
MODE=tests ./qemu/run_in_qemu.sh /boot/vmlinuz-6.17.0-42-generic /usr/src/linux-headers-6.17.0-42-generic
```

El kernel se arrancó con `oops=panic`, así que cualquier error del módulo habría detenido la ejecución. Al descargar el módulo, `dmesg` no mostró `BUG`, `WARNING` ni `Oops`.

## Archivos

| Archivo | Contenido |
|---|---|
| `pruebas_90_de_90.log` | Salida completa de `scripts/run_all_tests.sh`: cada verificación con su `[PASS]`, la demostración de evasión con `LD_PRELOAD` (sin y con el módulo), la carga y descarga del módulo y los mensajes del kernel |
| `estado_final_modulo.txt` | Contenido de `/proc/mmguard/stats` y de `/proc/mmguard/log` al terminar las pruebas |
| `auditoria_ebpf.txt` | Salida de `ebpf/mmap_audit.bt` ejecutado con `scripts/ebpf_workload.sh` |
| `benchmark.csv` | Datos crudos de `bench/bench_mmap` en los cuatro escenarios (A sin módulo, B sin reglas, C 64 reglas, D 64 reglas con auditoría) |
| `benchmark_resumen.txt` | Tabla comparativa del benchmark con las razones B/A, C/A y D/A (generada a partir de `benchmark.csv` con el mismo `awk` de `scripts/run_bench.sh`) |
| `strace_benchmark.txt` | Salida de `strace -c` sobre el benchmark |
| `ejecucion_completa_vm.log` | Registro completo de la consola de la máquina virtual (arranque, pruebas, eBPF y benchmark) |
| `compilacion_kernel_5.15.0-203.log` | Salida completa de `make V=1` contra los encabezados de Linux 5.15.0-203 (con gcc 11): comandos del compilador (con `-Wall -Werror`), código de salida, conteo de advertencias y `modinfo` del módulo (`vermagic 5.15.0-203-generic`) |
| `compilacion_kernel_6.8.0-147.log` | Lo mismo contra Linux 6.8.0-147 (gcc 13, `vermagic 6.8.0-147-generic`) |
| `compilacion_kernel_6.17.0-42.log` | Lo mismo contra Linux 6.17.0-42 (gcc 13, `vermagic 6.17.0-42-generic`) |
| `pruebas_codigo_final_kernel_5.15.0-203.log` | Batería completa con el código final en una VM con kernel 5.15.0-203: 90 PASS, 0 FAIL |
| `pruebas_codigo_final_kernel_6.17.0-42.log` | Batería completa con el código final en una VM con kernel 6.17.0-42: 90 PASS, 0 FAIL |

Para revisar rápidamente el resultado:

```bash
grep -c "\[PASS\]" pruebas_90_de_90.log     # 90
grep -c "\[FAIL\]" pruebas_90_de_90.log     # 0
grep -E "test_[a-z]+: |RESULTADO" pruebas_90_de_90.log
```

## Nota sobre `check_ns_avg`

`estado_final_modulo.txt` muestra `check_ns_avg 8206`, mientras el informe usa 969 ns. Son corridas distintas. El 8206 es de la batería de pruebas, con solo 131 decisiones de política (108 `mmap` y 23 `mprotect`); con tan pocas muestras, unos pocos valores atípicos de la emulación inflan el promedio (el máximo fue 376 490 ns). El 969 es de la corrida del benchmark, con 428 468 decisiones, y es la cifra representativa (ver `ejecucion_completa_vm.log`, sección BENCHMARK).
