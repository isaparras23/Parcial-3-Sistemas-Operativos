// SPDX-License-Identifier: GPL-2.0
/**
 * @file mmguard_vault.c
 * @brief /dev/mmvault : boveda cifrada que se proyecta con mmap() y se descifra
 *        PAGINA A PAGINA dentro del manejador de page faults del driver.
 *
 * ============================================================================
 * IDEA CENTRAL (respuesta practica a la pregunta 5 del parcial)
 * ============================================================================
 *  Almacenamiento ("lo que veria el disco"):
 *      ct[i]  = AES-256-CTR(K_enc, IV = i || version_i, texto_plano_i)
 *      tag[i] = HMAC-SHA256(K_mac, i || version_i || ct[i])   (Encrypt-then-MAC)
 *
 *  Al hacer mmap() el driver NO mapea nada (paginacion por demanda, igual que
 *  el paso 6 del repositorio CapaKernel). En el primer acceso a la pagina i la
 *  MMU dispara #PF y el kernel llama a mmv_fault(), que:
 *      1. Verifica tag[i] en tiempo constante  -> si falla: SIGBUS + auditoria.
 *      2. Reserva una pagina fisica NUEVA y PRIVADA de esa proyeccion.
 *      3. Descifra ct[i] en ella y la entrega a la PTE (vmf->page).
 *
 *  Garantias de aislamiento de la pagina descifrada:
 *    - Una pagina en claro por PROYECCION: dos procesos autorizados nunca
 *      comparten el mismo marco fisico en claro (no hay Page Cache compartido).
 *    - VM_DONTCOPY : fork() no hereda la proyeccion.
 *    - VM_DONTDUMP : el texto plano no aparece en core dumps.
 *    - VM_IO       : get_user_pages() la rechaza -> process_vm_readv(),
 *                    /proc/<pid>/mem, ptrace(PEEKDATA), O_DIRECT y vmsplice
 *                    no pueden leer el texto plano desde otro proceso.
 *    - Se exige MAP_SHARED: un MAP_PRIVATE escribible crearia copias COW
 *      anonimas FUERA del control del driver (y se liberarian sin borrar).
 *    - Las paginas del driver no estan en la LRU: nunca van a swap en claro.
 *    - Al munmap(): si la pagina cambio, se RE-CIFRA con version+1 (IV nuevo,
 *      nunca se reutiliza un nonce de CTR); luego se pone a cero
 *      (memzero_explicit) antes de devolverla al buddy allocator.
 *
 *  Control de acceso: solo el uid "vault_owner" (parametro del modulo) puede
 *  leer, escribir o proyectar. El permiso 0666 del nodo es intencional: la
 *  decision la toma el kernel (control obligatorio), no los bits DAC.
 * ============================================================================
 */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/slab.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/kref.h>
#include <linux/random.h>
#include <linux/scatterlist.h>
#include <linux/cred.h>
#include <linux/capability.h>
#include <linux/version.h>
#include <crypto/skcipher.h>
#include <crypto/hash.h>
#include <crypto/algapi.h>      /* crypto_memneq() */
#include "mmguard.h"

static unsigned int vault_pages = 16;
module_param(vault_pages, uint, 0444);
MODULE_PARM_DESC(vault_pages, "Capacidad de la boveda en paginas (1..1024)");

static unsigned int vault_owner;
module_param(vault_owner, uint, 0444);
MODULE_PARM_DESC(vault_owner, "Unico uid autorizado a descifrar/proyectar la boveda");

static bool debug_tamper;
module_param(debug_tamper, bool, 0444);
MODULE_PARM_DESC(debug_tamper, "Habilita MMV_IOC_DEBUG_CORRUPT para pruebas de integridad");

#define MMV_TAG_LEN 32          /* HMAC-SHA256 */

struct mmv_store {
	struct mutex                  lock;
	struct page                 **ct;       /* paginas cifradas                */
	u32                          *ver;      /* version por pagina (para el IV) */
	u8                          (*tag)[MMV_TAG_LEN];
	size_t                        data_len;
	struct crypto_sync_skcipher  *enc;      /* ctr(aes)                        */
	struct crypto_shash          *mac;      /* hmac(sha256)                    */
	atomic_t                      active_maps;
};
static struct mmv_store V;

/** Estado de una proyeccion (compartido por los VMAs que resultan de un split). */
struct mmv_sess {
	struct kref     ref;
	struct page   **pt;                     /* paginas en claro de ESTE mapeo  */
	u8            (*ph)[MMV_TAG_LEN];       /* huella del claro al descifrar   */
	bool            may_write;
};

/* ------------------------------------------------------------------------- */
/* Primitivas criptograficas                                                 */
/* ------------------------------------------------------------------------- */
static void mmv_iv(u8 iv[16], u32 idx, u32 ver)
{
	int i;

	memset(iv, 0, 16);
	for (i = 0; i < 4; i++) {
		iv[i]     = (u8)(idx >> (24 - 8 * i));
		iv[4 + i] = (u8)(ver >> (24 - 8 * i));
	}
	/* bytes 8..15 = contador de bloque de CTR (0..255 para una pagina de 4 KiB) */
}

/* AES-CTR es simetrico: la misma operacion cifra y descifra. */
static int mmv_ctr(u32 idx, u32 ver, struct page *in, struct page *out)
{
	SYNC_SKCIPHER_REQUEST_ON_STACK(req, V.enc);
	struct scatterlist sin, sout;
	u8 iv[16];
	int err;

	mmv_iv(iv, idx, ver);
	sg_init_table(&sin, 1);
	sg_set_page(&sin, in, PAGE_SIZE, 0);
	sg_init_table(&sout, 1);
	sg_set_page(&sout, out, PAGE_SIZE, 0);
	skcipher_request_set_sync_tfm(req, V.enc);
	skcipher_request_set_callback(req, 0, NULL, NULL);
	skcipher_request_set_crypt(req, &sin, &sout, PAGE_SIZE, iv);
	err = crypto_skcipher_encrypt(req);
	skcipher_request_zero(req);
	return err;
}

static int mmv_hmac(u32 idx, u32 ver, const void *data, u8 out[MMV_TAG_LEN])
{
	SHASH_DESC_ON_STACK(desc, V.mac);
	__le32 hdr[2] = { cpu_to_le32(idx), cpu_to_le32(ver) };
	int err;

	desc->tfm = V.mac;
	err = crypto_shash_init(desc);
	if (!err)
		err = crypto_shash_update(desc, (const u8 *)hdr, sizeof(hdr));
	if (!err)
		err = crypto_shash_update(desc, data, PAGE_SIZE);
	if (!err)
		err = crypto_shash_final(desc, out);
	shash_desc_zero(desc);
	return err;
}

/** Cifra 'plain' en la ranura idx con una version NUEVA. Requiere V.lock. */
static int mmv_seal(u32 idx, struct page *plain)
{
	u32 nv = V.ver[idx] + 1;
	int err = mmv_ctr(idx, nv, plain, V.ct[idx]);

	if (err)
		return err;
	V.ver[idx] = nv;
	return mmv_hmac(idx, nv, page_address(V.ct[idx]), V.tag[idx]);
}

/** Verifica integridad y descifra la ranura idx en 'plain'. Requiere V.lock. */
static int mmv_unseal(u32 idx, struct page *plain)
{
	u8 t[MMV_TAG_LEN];
	int err = mmv_hmac(idx, V.ver[idx], page_address(V.ct[idx]), t);

	if (err)
		return err;
	if (crypto_memneq(t, V.tag[idx], MMV_TAG_LEN)) {
		atomic64_inc(&mmg_stats.vault_tamper);
		mmg_audit(MMG_EV_VAULT_TAMPER, true, idx, 0, V.ver[idx], "hmac_invalido");
		return -EBADMSG;
	}
	return mmv_ctr(idx, V.ver[idx], V.ct[idx], plain);
}

/* ------------------------------------------------------------------------- */
/* Control de acceso                                                         */
/* ------------------------------------------------------------------------- */
static bool mmv_authorized(void)
{
	return uid_eq(current_fsuid(), make_kuid(&init_user_ns, vault_owner));
}

static int mmv_deny(const char *why)
{
	atomic64_inc(&mmg_stats.vault_denied);
	mmg_audit(MMG_EV_VAULT_DENY, true, 0, 0, 0, why);
	return -EACCES;
}

static loff_t mmv_capacity(void)
{
	return (loff_t)vault_pages << PAGE_SHIFT;
}

/* ------------------------------------------------------------------------- */
/* read()/write(): ruta clasica (copy_to_user / copy_from_user)               */
/* IMPORTANTE: nunca se toca memoria de usuario con V.lock tomado. Si el      */
/* buffer de usuario fuera una proyeccion de la boveda, copy_*_user() haria   */
/* un #PF que entraria a mmv_fault() y pediria V.lock => auto-interbloqueo    */
/* (orden mmap_lock -> V.lock vs V.lock -> mmap_lock). Se usa un bounce page. */
/* ------------------------------------------------------------------------- */
static ssize_t mmv_read(struct file *f, char __user *ubuf, size_t len, loff_t *ppos)
{
	struct page *tmp;
	loff_t pos = *ppos;
	size_t done = 0;
	int err = 0;

	if (!mmv_authorized())
		return mmv_deny("read_no_autorizado");
	tmp = alloc_page(GFP_KERNEL);
	if (!tmp)
		return -ENOMEM;

	while (done < len) {
		u32 idx = pos >> PAGE_SHIFT;
		size_t off = pos & ~PAGE_MASK, n;

		mutex_lock(&V.lock);
		if (pos >= V.data_len) {
			mutex_unlock(&V.lock);
			break;
		}
		n = min3(len - done, (size_t)(PAGE_SIZE - off), (size_t)(V.data_len - pos));
		err = mmv_unseal(idx, tmp);
		mutex_unlock(&V.lock);
		if (err)
			break;
		if (copy_to_user(ubuf + done, page_address(tmp) + off, n)) {
			err = -EFAULT;
			break;
		}
		done += n;
		pos += n;
	}
	memzero_explicit(page_address(tmp), PAGE_SIZE);
	__free_page(tmp);
	*ppos = pos;
	return done ? (ssize_t)done : err;
}

static ssize_t mmv_write(struct file *f, const char __user *ubuf, size_t len, loff_t *ppos)
{
	struct page *tmp, *in;
	loff_t pos = *ppos;
	size_t done = 0;
	int err = 0;

	if (!mmv_authorized())
		return mmv_deny("write_no_autorizado");
	if (pos >= mmv_capacity())
		return len ? -ENOSPC : 0;
	tmp = alloc_page(GFP_KERNEL);
	in = alloc_page(GFP_KERNEL);
	if (!tmp || !in) {
		err = -ENOMEM;
		goto out;
	}

	while (done < len && pos < mmv_capacity()) {
		u32 idx = pos >> PAGE_SHIFT;
		size_t off = pos & ~PAGE_MASK;
		size_t n = min(len - done, (size_t)(PAGE_SIZE - off));

		if (copy_from_user(page_address(in), ubuf + done, n)) {   /* sin lock */
			err = -EFAULT;
			break;
		}
		mutex_lock(&V.lock);
		err = mmv_unseal(idx, tmp);                 /* lectura-modificacion-escritura */
		if (!err) {
			memcpy(page_address(tmp) + off, page_address(in), n);
			err = mmv_seal(idx, tmp);
		}
		if (!err && pos + n > V.data_len)
			V.data_len = pos + n;
		mutex_unlock(&V.lock);
		if (err)
			break;
		done += n;
		pos += n;
	}
out:
	if (tmp) {
		memzero_explicit(page_address(tmp), PAGE_SIZE);
		__free_page(tmp);
	}
	if (in) {
		memzero_explicit(page_address(in), PAGE_SIZE);
		__free_page(in);
	}
	*ppos = pos;
	return done ? (ssize_t)done : err;
}

static loff_t mmv_llseek(struct file *f, loff_t off, int whence)
{
	return fixed_size_llseek(f, off, whence, mmv_capacity());
}

/* ------------------------------------------------------------------------- */
/* mmap(): operaciones de memoria virtual                                     */
/* ------------------------------------------------------------------------- */
static void mmv_sess_release(struct kref *ref)
{
	struct mmv_sess *s = container_of(ref, struct mmv_sess, ref);
	u8 h[MMV_TAG_LEN];
	u32 idx;

	mutex_lock(&V.lock);
	for (idx = 0; idx < vault_pages; idx++) {
		struct page *pg = s->pt[idx];

		if (!pg)
			continue;
		/* Write-back: solo si la proyeccion era escribible y la pagina cambio. */
		if (s->may_write && !mmv_hmac(idx, ~0u, page_address(pg), h) &&
		    crypto_memneq(h, s->ph[idx], MMV_TAG_LEN)) {
			if (!mmv_seal(idx, pg)) {
				loff_t end = (loff_t)(idx + 1) << PAGE_SHIFT;

				if (end > V.data_len)
					V.data_len = end;
				atomic64_inc(&mmg_stats.vault_writebacks);
				mmg_audit(MMG_EV_VAULT_WRITEBACK, false, idx, 0,
					  V.ver[idx], "re-cifrado");
			}
		}
		/* El texto plano jamas regresa al allocator sin borrarse. */
		memzero_explicit(page_address(pg), PAGE_SIZE);
		ClearPageDirty(pg);
		put_page(pg);
	}
	mutex_unlock(&V.lock);
	memzero_explicit(s->ph, vault_pages * MMV_TAG_LEN);
	kvfree(s->ph);
	kvfree(s->pt);
	kfree(s);
	atomic_dec(&V.active_maps);
}

static void mmv_vma_open(struct vm_area_struct *vma)
{
	/* Split de VMA (munmap/mprotect parcial): ambos trozos comparten la sesion. */
	kref_get(&((struct mmv_sess *)vma->vm_private_data)->ref);
}

static void mmv_vma_close(struct vm_area_struct *vma)
{
	/* Se invoca DESPUES de que el kernel desmonto las PTE de este VMA. */
	kref_put(&((struct mmv_sess *)vma->vm_private_data)->ref, mmv_sess_release);
}

static vm_fault_t mmv_fault(struct vm_fault *vmf)
{
	struct mmv_sess *s = vmf->vma->vm_private_data;
	pgoff_t idx = vmf->pgoff;
	struct page *pg;

	if (idx >= vault_pages)
		return VM_FAULT_SIGBUS;

	mutex_lock(&V.lock);
	pg = s->pt[idx];
	if (!pg) {
		pg = alloc_page(GFP_KERNEL | __GFP_ZERO);
		if (!pg) {
			mutex_unlock(&V.lock);
			return VM_FAULT_OOM;
		}
		if (mmv_unseal(idx, pg) || mmv_hmac(idx, ~0u, page_address(pg), s->ph[idx])) {
			mutex_unlock(&V.lock);
			memzero_explicit(page_address(pg), PAGE_SIZE);
			__free_page(pg);
			return VM_FAULT_SIGBUS;     /* integridad comprometida: no se entrega nada */
		}
		s->pt[idx] = pg;
		atomic64_inc(&mmg_stats.vault_faults);
	}
	/* Referencia para la PTE; el kernel la libera al desmapear. */
	get_page(pg);
	mutex_unlock(&V.lock);
	vmf->page = pg;
	return 0;
}

static const struct vm_operations_struct mmv_vm_ops = {
	.open  = mmv_vma_open,
	.close = mmv_vma_close,
	.fault = mmv_fault,
};

static int mmv_mmap(struct file *f, struct vm_area_struct *vma)
{
	struct mmv_sess *s;

	if (!mmv_authorized())
		return mmv_deny("mmap_no_autorizado");
	/* VM_MAYSHARE (no VM_SHARED): un MAP_SHARED sobre fd O_RDONLY limpia VM_SHARED. */
	if (!(vma->vm_flags & VM_MAYSHARE)) {
		mmg_audit(MMG_EV_VAULT_DENY, true, 0, 0, vma->vm_flags, "map_private");
		return -EINVAL;
	}
	if (vma->vm_flags & VM_EXEC) {
		mmg_audit(MMG_EV_VAULT_DENY, true, 0, 0, vma->vm_flags, "prot_exec");
		return -EPERM;
	}
	if (vma->vm_pgoff + vma_pages(vma) > vault_pages)
		return -EINVAL;

	s = kzalloc(sizeof(*s), GFP_KERNEL);
	if (!s)
		return -ENOMEM;
	s->pt = kvcalloc(vault_pages, sizeof(*s->pt), GFP_KERNEL);
	s->ph = kvcalloc(vault_pages, MMV_TAG_LEN, GFP_KERNEL);
	if (!s->pt || !s->ph) {
		kvfree(s->pt);
		kvfree(s->ph);
		kfree(s);
		return -ENOMEM;
	}
	kref_init(&s->ref);
	s->may_write = !!(vma->vm_flags & VM_MAYWRITE);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 3, 0)
	vm_flags_set(vma, VM_IO | VM_DONTCOPY | VM_DONTDUMP | VM_DONTEXPAND);
	vm_flags_clear(vma, VM_MAYEXEC);       /* mprotect(PROT_EXEC) imposible */
#else
	vma->vm_flags |= VM_IO | VM_DONTCOPY | VM_DONTDUMP | VM_DONTEXPAND;
	vma->vm_flags &= ~VM_MAYEXEC;
#endif
	vma->vm_ops = &mmv_vm_ops;
	vma->vm_private_data = s;
	atomic_inc(&V.active_maps);
	mmg_audit(MMG_EV_VAULT_MMAP, false, vma->vm_pgoff, vma_pages(vma),
		  vma->vm_flags, s->may_write ? "rw" : "ro");
	return 0;
}

/* ------------------------------------------------------------------------- */
/* ioctl()                                                                    */
/* ------------------------------------------------------------------------- */
static long mmv_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
	void __user *uarg = (void __user *)arg;

	switch (cmd) {
	case MMV_IOC_INFO: {
		struct mmv_info info = {
			.page_size   = PAGE_SIZE,
			.npages      = vault_pages,
			.owner_uid   = vault_owner,
			.active_maps = atomic_read(&V.active_maps),
			.faults      = atomic64_read(&mmg_stats.vault_faults),
			.writebacks  = atomic64_read(&mmg_stats.vault_writebacks),
			.tamper      = atomic64_read(&mmg_stats.vault_tamper),
			.denied      = atomic64_read(&mmg_stats.vault_denied),
		};

		mutex_lock(&V.lock);
		info.data_len = V.data_len;
		mutex_unlock(&V.lock);
		return copy_to_user(uarg, &info, sizeof(info)) ? -EFAULT : 0;
	}
	case MMV_IOC_GET_CIPHER: {
		struct mmv_cipher_req req;
		struct page *tmp;
		long ret = 0;

		if (!mmv_authorized())
			return mmv_deny("ioctl_no_autorizado");
		if (copy_from_user(&req, uarg, sizeof(req)))
			return -EFAULT;
		if (req.page >= vault_pages)
			return -EINVAL;
		tmp = alloc_page(GFP_KERNEL);
		if (!tmp)
			return -ENOMEM;
		mutex_lock(&V.lock);
		memcpy(page_address(tmp), page_address(V.ct[req.page]), PAGE_SIZE);
		req.version = V.ver[req.page];
		mutex_unlock(&V.lock);
		if (copy_to_user(u64_to_user_ptr(req.buf), page_address(tmp), PAGE_SIZE) ||
		    copy_to_user(uarg, &req, sizeof(req)))
			ret = -EFAULT;
		__free_page(tmp);
		return ret;
	}
	case MMV_IOC_DEBUG_CORRUPT: {
		u32 idx;

		if (!debug_tamper || !capable(CAP_SYS_ADMIN))
			return -EPERM;
		if (get_user(idx, (u32 __user *)uarg))
			return -EFAULT;
		if (idx >= vault_pages)
			return -EINVAL;
		mutex_lock(&V.lock);
		((u8 *)page_address(V.ct[idx]))[0] ^= 0x5A;   /* un bit-flip basta */
		mutex_unlock(&V.lock);
		return 0;
	}
	case MMV_IOC_WIPE: {
		struct page *zero;
		u32 idx;
		int err = 0;

		if (!mmv_authorized())
			return mmv_deny("wipe_no_autorizado");
		zero = alloc_page(GFP_KERNEL | __GFP_ZERO);
		if (!zero)
			return -ENOMEM;
		mutex_lock(&V.lock);
		for (idx = 0; idx < vault_pages && !err; idx++)
			err = mmv_seal(idx, zero);
		V.data_len = 0;
		mutex_unlock(&V.lock);
		__free_page(zero);
		return err;
	}
	default:
		return -ENOTTY;
	}
}

static const struct file_operations mmv_fops = {
	.owner          = THIS_MODULE,
	.read           = mmv_read,
	.write          = mmv_write,
	.llseek         = mmv_llseek,
	.mmap           = mmv_mmap,
	.unlocked_ioctl = mmv_ioctl,
	.compat_ioctl   = compat_ptr_ioctl,
};

static struct miscdevice mmv_misc = {
	.minor = MISC_DYNAMIC_MINOR,
	.name  = "mmvault",
	.fops  = &mmv_fops,
	.mode  = 0666,
};

int mmg_vault_show(struct seq_file *m)
{
	seq_printf(m, "%-22s %u paginas, owner_uid=%u, data_len=%zu, mapeos_activos=%d\n",
		   "boveda", vault_pages, vault_owner, V.data_len,
		   atomic_read(&V.active_maps));
	return 0;
}

static void mmv_free_store(void)
{
	u32 i;

	if (V.ct) {
		for (i = 0; i < vault_pages; i++)
			if (V.ct[i])
				__free_page(V.ct[i]);
		kvfree(V.ct);
	}
	kvfree(V.ver);
	kvfree(V.tag);
	if (!IS_ERR_OR_NULL(V.enc))
		crypto_free_sync_skcipher(V.enc);
	if (!IS_ERR_OR_NULL(V.mac))
		crypto_free_shash(V.mac);
	memset(&V, 0, sizeof(V));
}

int mmg_vault_init(void)
{
	u8 key[64];             /* 32 bytes AES-256 + 32 bytes HMAC */
	struct page *zero;
	u32 i;
	int err;

	if (vault_pages < 1 || vault_pages > 1024)
		return -EINVAL;
	memset(&V, 0, sizeof(V));
	mutex_init(&V.lock);

	V.enc = crypto_alloc_sync_skcipher("ctr(aes)", 0, 0);
	if (IS_ERR(V.enc)) {
		err = PTR_ERR(V.enc);
		pr_err(MMG_NAME ": ctr(aes) no disponible (%d)\n", err);
		goto fail;
	}
	V.mac = crypto_alloc_shash("hmac(sha256)", 0, 0);
	if (IS_ERR(V.mac)) {
		err = PTR_ERR(V.mac);
		pr_err(MMG_NAME ": hmac(sha256) no disponible (%d)\n", err);
		goto fail;
	}

	/* Claves efimeras: viven solo en el contexto del cifrador dentro del
	 * kernel; nunca se exponen al usuario y se borran de la pila. */
	get_random_bytes(key, sizeof(key));
	err = crypto_sync_skcipher_setkey(V.enc, key, 32);
	if (!err)
		err = crypto_shash_setkey(V.mac, key + 32, 32);
	memzero_explicit(key, sizeof(key));
	if (err)
		goto fail;

	V.ct  = kvcalloc(vault_pages, sizeof(*V.ct), GFP_KERNEL);
	V.ver = kvcalloc(vault_pages, sizeof(*V.ver), GFP_KERNEL);
	V.tag = kvcalloc(vault_pages, MMV_TAG_LEN, GFP_KERNEL);
	zero  = alloc_page(GFP_KERNEL | __GFP_ZERO);
	if (!V.ct || !V.ver || !V.tag || !zero) {
		err = -ENOMEM;
		goto fail_zero;
	}
	for (i = 0; i < vault_pages; i++) {
		V.ct[i] = alloc_page(GFP_KERNEL);
		if (!V.ct[i]) {
			err = -ENOMEM;
			goto fail_zero;
		}
		err = mmv_seal(i, zero);          /* boveda vacia = ceros cifrados */
		if (err)
			goto fail_zero;
	}
	__free_page(zero);

	err = misc_register(&mmv_misc);
	if (err)
		goto fail;
	pr_info(MMG_NAME ": /dev/mmvault listo (%u paginas, owner uid=%u, AES-256-CTR + HMAC-SHA256)\n",
		vault_pages, vault_owner);
	return 0;

fail_zero:
	if (zero)
		__free_page(zero);
fail:
	mmv_free_store();
	return err;
}

void mmg_vault_exit(void)
{
	u32 i;  /* declarada aqui: antes de 5.18 el kernel compila en gnu89 */

	misc_deregister(&mmv_misc);
	/* No puede haber proyecciones vivas: cada VMA mantiene una referencia al
	 * struct file, y fops.owner=THIS_MODULE impide descargar el modulo. */
	if (V.ct)
		for (i = 0; i < vault_pages; i++)
			if (V.ct[i])
				memzero_explicit(page_address(V.ct[i]), PAGE_SIZE);
	mmv_free_store();
}
