// SPDX-License-Identifier: GPL-2.0
/**
 * @file mmguard_audit.c
 * @brief Subsistema de auditoria: anillo circular de eventos + contadores.
 *
 * DECISION DE DISENO:
 *   mmg_audit() se invoca desde manejadores de kprobes/kretprobes, que corren
 *   en contexto ATOMICO (preempcion deshabilitada; no se puede dormir). Por eso:
 *     - No se usa kmalloc(GFP_KERNEL) ni mutex: el anillo es un arreglo estatico.
 *     - La exclusion mutua es un spinlock con irqsave (un #PF puede ocurrir con
 *       cualquier estado de interrupciones del lado del llamador).
 *     - Los contadores son atomic64_t: se incrementan sin tomar el lock.
 *   Si el anillo se llena, se sobrescribe el evento mas antiguo (no se bloquea
 *   nunca la ruta critica del page fault por culpa de la auditoria).
 */
#include <linux/kernel.h>
#include <linux/spinlock.h>
#include <linux/sched.h>
#include <linux/cred.h>
#include <linux/ktime.h>
#include <linux/string.h>
#include <linux/mm.h>      /* kvmalloc_array / kvfree (en <linux/mm.h> antes de 6.x) */
#include <linux/slab.h>
#include "mmguard.h"

#define MMG_LOG_SIZE 256

struct mmg_log_entry {
	u64           ts_ns;
	pid_t         pid;
	u32           uid;
	char          comm[TASK_COMM_LEN];
	u8            ev;
	u8            denied;
	unsigned long ino;
	unsigned long prot;
	unsigned long flags;
	char          why[24];
};

struct mmg_stats mmg_stats;

static struct mmg_log_entry mmg_log[MMG_LOG_SIZE];
static unsigned int mmg_log_head;   /* siguiente posicion a escribir */
static u64 mmg_log_total;           /* eventos totales (incl. sobrescritos) */
static DEFINE_SPINLOCK(mmg_log_lock);

static const char *ev_name(u8 ev)
{
	switch (ev) {
	case MMG_EV_MMAP:            return "MMAP";
	case MMG_EV_MPROTECT:        return "MPROTECT";
	case MMG_EV_FAULT:           return "PAGE_FAULT";
	case MMG_EV_WX:              return "W^X";
	case MMG_EV_VAULT_MMAP:      return "VAULT_MMAP";
	case MMG_EV_VAULT_DENY:      return "VAULT_DENY";
	case MMG_EV_VAULT_WRITEBACK: return "VAULT_WRITEBACK";
	case MMG_EV_VAULT_TAMPER:    return "VAULT_TAMPER";
	case MMG_EV_POLICY:          return "POLICY";
	default:                     return "?";
	}
}

int mmg_audit_init(void)
{
	memset(&mmg_stats, 0, sizeof(mmg_stats));
	mmg_log_head = 0;
	mmg_log_total = 0;
	return 0;
}

void mmg_audit_exit(void)
{
	/* Nada dinamico que liberar: el anillo es estatico. */
}

/**
 * mmg_audit - registra un evento de seguridad (seguro en contexto atomico).
 */
void mmg_audit(enum mmg_event ev, bool denied, unsigned long ino,
	       unsigned long prot, unsigned long flags, const char *why)
{
	struct mmg_log_entry *e;
	unsigned long irqf;

	spin_lock_irqsave(&mmg_log_lock, irqf);
	e = &mmg_log[mmg_log_head];
	e->ts_ns  = ktime_get_ns();
	e->pid    = current->pid;
	e->uid    = from_kuid(&init_user_ns, current_uid());
	get_task_comm(e->comm, current);
	e->ev     = (u8)ev;
	e->denied = denied;
	e->ino    = ino;
	e->prot   = prot;
	e->flags  = flags;
	strscpy(e->why, why ? why : "-", sizeof(e->why));
	mmg_log_head = (mmg_log_head + 1) % MMG_LOG_SIZE;
	mmg_log_total++;
	spin_unlock_irqrestore(&mmg_log_lock, irqf);

	if (denied)
		pr_notice_ratelimited(MMG_NAME ": DENEGADO %s pid=%d comm=%s ino=%lu prot=0x%lx flags=0x%lx (%s)\n",
				      ev_name(ev), current->pid, current->comm,
				      ino, prot, flags, why ? why : "-");
}

/** /proc/mmguard/log : vuelca el anillo del evento mas antiguo al mas nuevo. */
int mmg_audit_show(struct seq_file *m, void *v)
{
	struct mmg_log_entry *snap;
	unsigned int i, n, start;
	unsigned long irqf;
	u64 total;

	/* Se copia el anillo bajo el lock y se imprime fuera de el:
	 * seq_printf puede ser lento y no queremos retener el spinlock. */
	snap = kvmalloc_array(MMG_LOG_SIZE, sizeof(*snap), GFP_KERNEL);
	if (!snap)
		return -ENOMEM;

	spin_lock_irqsave(&mmg_log_lock, irqf);
	memcpy(snap, mmg_log, sizeof(mmg_log));
	total = mmg_log_total;
	start = mmg_log_head;
	spin_unlock_irqrestore(&mmg_log_lock, irqf);

	n = total < MMG_LOG_SIZE ? (unsigned int)total : MMG_LOG_SIZE;
	if (total < MMG_LOG_SIZE)
		start = 0;

	seq_printf(m, "# eventos_totales=%llu mostrados=%u\n", total, n);
	seq_puts(m, "# ts_ns            pid    uid   comm             evento          veredicto inode      prot  flags   motivo\n");
	for (i = 0; i < n; i++) {
		struct mmg_log_entry *e = &snap[(start + i) % MMG_LOG_SIZE];

		seq_printf(m, "%-18llu %-6d %-5u %-16s %-15s %-9s %-10lu 0x%-3lx 0x%-5lx %s\n",
			   e->ts_ns, e->pid, e->uid, e->comm, ev_name(e->ev),
			   e->denied ? "DENEGADO" : "PERMITIDO",
			   e->ino, e->prot, e->flags, e->why);
	}
	kvfree(snap);
	return 0;
}

/** Actualiza tiempo total y maximo de la decision de politica (sin locks). */
void mmg_stats_add_time(u64 ns)
{
	s64 old;

	atomic64_add(ns, &mmg_stats.check_ns_total);
	old = atomic64_read(&mmg_stats.check_ns_max);
	while ((s64)ns > old) {
		s64 prev = atomic64_cmpxchg(&mmg_stats.check_ns_max, old, ns);

		if (prev == old)
			break;
		old = prev;
	}
}

#define SHOW(name) seq_printf(m, "%-22s %lld\n", #name, atomic64_read(&mmg_stats.name))

/** /proc/mmguard/stats */
int mmg_stats_show(struct seq_file *m, void *v)
{
	s64 checks = atomic64_read(&mmg_stats.mmap_checked) +
		     atomic64_read(&mmg_stats.mprotect_checked);

	seq_printf(m, "%-22s %s\n", "modo", mmg_enforce ? "enforcing" : "permissive");
	SHOW(mmap_checked);
	SHOW(mmap_denied);
	SHOW(mprotect_checked);
	SHOW(mprotect_denied);
	SHOW(wx_denied);
	SHOW(audit_only);
	SHOW(faults_audited);
	SHOW(vault_faults);
	SHOW(vault_writebacks);
	SHOW(vault_tamper);
	SHOW(vault_denied);
	seq_printf(m, "%-22s %lld\n", "check_ns_avg",
		   checks ? atomic64_read(&mmg_stats.check_ns_total) / checks : 0);
	SHOW(check_ns_max);
	return mmg_vault_show(m);
}
