// SPDX-License-Identifier: GPL-2.0
/**
 * @file mmguard_policy.c
 * @brief Motor de politica: intercepta el ALTA del VMA (mmap), el CAMBIO de
 *        permisos (mprotect) y AUDITA los page faults de archivos protegidos.
 *
 * ============================================================================
 * POR QUE kretprobes SOBRE LOS GANCHOS LSM Y NO "HOOK" DE LA SYSCALL TABLE
 * ============================================================================
 *  - Desde Linux 4.12 los LSM no pueden registrarse desde un modulo cargable
 *    (security_add_hooks() es __init y la tabla de hooks es __ro_after_init).
 *  - Parchear sys_call_table exige kallsyms_lookup_name (no exportado desde
 *    5.7) y quitar el bit WP de CR0 (bloqueado/"pinned" desde 5.3). Ademas
 *    solo veria sys_mmap, NO mprotect ni las rutas internas (execve, ELF loader).
 *  - security_mmap_file() y security_file_mprotect() son los puntos por donde
 *    TODA proyeccion/cambio de proteccion pasa, sin importar el origen (libc,
 *    syscall() directa, cargador ELF, io_uring...). Engancharlos con una
 *    kretprobe nos da la MISMA semantica de un LSM sin recompilar el kernel:
 *    si la politica lo prohibe, el valor de retorno se reemplaza por -EACCES.
 *
 * IDENTIDAD POR INODO, NO POR RUTA:
 *   Las reglas guardan (s_dev, i_ino). Asi un atacante no evade la politica con
 *   un hard link, un symlink, un rename o una ruta relativa "../".
 *
 * CONCURRENCIA:
 *   Lectores (probes, contexto atomico) recorren la lista con RCU: costo casi
 *   nulo y sin locks en la ruta caliente. Escritores (/proc/mmguard/policy,
 *   contexto de proceso) se serializan con un mutex y liberan con kfree_rcu().
 * ============================================================================
 */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kprobes.h>
#include <linux/fs.h>
#include <linux/namei.h>
#include <linux/mm.h>
#include <linux/mman.h>
#include <linux/slab.h>
#include <linux/rculist.h>
#include <linux/mutex.h>
#include <linux/cred.h>
#include <linux/ktime.h>
#include <linux/string.h>
#include <linux/ptrace.h>
#include "mmguard.h"

struct mmg_rule {
	struct list_head list;
	dev_t            dev;
	unsigned long    ino;
	u32              flags;
	bool             has_uid;
	kuid_t           allow_uid;
	char             path[128];     /* solo informativo (la identidad es el inodo) */
	atomic64_t       mmaps;
	atomic64_t       denials;
	atomic64_t       faults;
	struct rcu_head  rcu;
};

static LIST_HEAD(mmg_rules);
static DEFINE_MUTEX(mmg_rules_lock);
static atomic_t mmg_nrules = ATOMIC_INIT(0);
static bool mmg_wx_deny;        /* politica global W^X */

/* ------------------------------------------------------------------------- */
/* Busqueda de regla (lector RCU)                                            */
/* ------------------------------------------------------------------------- */
static struct mmg_rule *mmg_lookup_rcu(struct file *file)
{
	struct mmg_rule *r;
	struct inode *inode;

	if (!file || !atomic_read(&mmg_nrules))
		return NULL;
	inode = file_inode(file);
	list_for_each_entry_rcu(r, &mmg_rules, list) {
		if (r->ino == inode->i_ino && r->dev == inode->i_sb->s_dev)
			return r;
	}
	return NULL;
}

/**
 * mmg_decide - aplica las banderas de una regla a una peticion (prot, shared).
 * Devuelve NULL si se permite, o un texto con el motivo de la denegacion.
 */
static const char *mmg_decide(const struct mmg_rule *r, unsigned long prot, bool shared)
{
	if ((r->flags & MMG_F_DENY_ALL) &&
	    !(r->has_uid && uid_eq(current_fsuid(), r->allow_uid)))
		return "deny_all";
	if ((r->flags & MMG_F_NO_SHARED_WRITE) && shared && (prot & PROT_WRITE))
		return "shared_write";
	if ((r->flags & MMG_F_NO_PRIVATE_WRITE) && !shared && (prot & PROT_WRITE))
		return "private_write";
	if ((r->flags & MMG_F_NO_EXEC) && (prot & PROT_EXEC))
		return "exec";
	return NULL;
}

/** Politica W^X: ninguna pagina puede ser escribible y ejecutable a la vez. */
static const char *mmg_wx_check(struct file *file, unsigned long prot, bool is_mprotect)
{
	if (!READ_ONCE(mmg_wx_deny))
		return NULL;
	if ((prot & PROT_WRITE) && (prot & PROT_EXEC))
		return "wx_simultaneo";
	/* Patron clasico de shellcode: mmap(RW) anonimo -> escribir -> mprotect(RX). */
	if (is_mprotect && !file && (prot & PROT_EXEC))
		return "anon_exec";
	return NULL;
}

/* ------------------------------------------------------------------------- */
/* Contexto compartido entre entry_handler y ret_handler de las kretprobes   */
/* ------------------------------------------------------------------------- */
struct mmg_probe_ctx {
	const char   *why;      /* NULL = permitido                         */
	unsigned long ino;
	unsigned long prot;
	unsigned long flags;
	bool          audit;
	u8            ev;
};

/* Evalua y deja el veredicto en ctx (corre ANTES del gancho original). */
static void mmg_evaluate(struct mmg_probe_ctx *c, struct file *file,
			 unsigned long prot, unsigned long flags, bool shared,
			 bool is_mprotect)
{
	struct mmg_rule *r;
	u64 t0 = ktime_get_ns();

	c->why = NULL;
	c->audit = false;
	c->prot = prot;
	c->flags = flags;
	c->ino = file ? file_inode(file)->i_ino : 0;
	c->ev = is_mprotect ? MMG_EV_MPROTECT : MMG_EV_MMAP;

	c->why = mmg_wx_check(file, prot, is_mprotect);
	if (c->why) {
		c->ev = MMG_EV_WX;
		c->audit = true;
		goto out;
	}

	rcu_read_lock();
	r = mmg_lookup_rcu(file);
	if (r) {
		atomic64_inc(&r->mmaps);
		c->why = mmg_decide(r, prot, shared);
		c->audit = (r->flags & MMG_F_AUDIT) || c->why;
		if (c->why)
			atomic64_inc(&r->denials);
	}
	rcu_read_unlock();
out:
	mmg_stats_add_time(ktime_get_ns() - t0);
}

/* Aplica el veredicto en el RETORNO del gancho (reescribe el valor de retorno). */
static void mmg_apply(struct mmg_probe_ctx *c, struct pt_regs *regs,
		      atomic64_t *denied_ctr)
{
	bool deny;

	if (!c->why && !c->audit)
		return;
	/* Si otro LSM (AppArmor, SELinux...) ya nego, respetamos su error. */
	if (c->why && regs_return_value(regs) != 0)
		return;

	deny = c->why && READ_ONCE(mmg_enforce);
	if (deny) {
		regs_set_return_value(regs, (unsigned long)-EACCES);
		atomic64_inc(denied_ctr);
		if (c->ev == MMG_EV_WX)
			atomic64_inc(&mmg_stats.wx_denied);
	} else if (c->why) {
		atomic64_inc(&mmg_stats.audit_only);
	}
	if (c->audit)
		mmg_audit(c->ev, deny, c->ino, c->prot, c->flags,
			  c->why ? c->why : (deny ? "-" : "permitido"));
}

/* ---- kretprobe 1: int security_mmap_file(struct file *, ulong prot, ulong flags) ---- */
static int mmap_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct mmg_probe_ctx *c = (struct mmg_probe_ctx *)ri->data;
	struct file *file = (struct file *)regs_get_kernel_argument(regs, 0);
	unsigned long prot = regs_get_kernel_argument(regs, 1);
	unsigned long flags = regs_get_kernel_argument(regs, 2);
	unsigned long type = flags & MAP_TYPE;
	bool shared = (type == MAP_SHARED || type == MAP_SHARED_VALIDATE);

	atomic64_inc(&mmg_stats.mmap_checked);
	mmg_evaluate(c, file, prot, flags, shared, false);
	return 0;
}

static int mmap_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	mmg_apply((struct mmg_probe_ctx *)ri->data, regs, &mmg_stats.mmap_denied);
	return 0;
}

static struct kretprobe mmg_krp_mmap = {
	.kp.symbol_name = "security_mmap_file",
	.entry_handler  = mmap_entry,
	.handler        = mmap_ret,
	.data_size      = sizeof(struct mmg_probe_ctx),
	.maxactive      = 256,  /* instancias simultaneas; si se agotan, nmissed++ */
};

/* ---- kretprobe 2: int security_file_mprotect(vma, ulong reqprot, ulong prot) ---- */
static int mprot_entry(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	struct mmg_probe_ctx *c = (struct mmg_probe_ctx *)ri->data;
	struct vm_area_struct *vma = (struct vm_area_struct *)regs_get_kernel_argument(regs, 0);
	unsigned long reqprot = regs_get_kernel_argument(regs, 1);

	atomic64_inc(&mmg_stats.mprotect_checked);
	/* mprotect() se ejecuta con mmap_lock tomado en escritura: vma es estable. */
	mmg_evaluate(c, vma->vm_file, reqprot, vma->vm_flags,
		     !!(vma->vm_flags & VM_SHARED), true);
	return 0;
}

static int mprot_ret(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	mmg_apply((struct mmg_probe_ctx *)ri->data, regs, &mmg_stats.mprotect_denied);
	return 0;
}

static struct kretprobe mmg_krp_mprotect = {
	.kp.symbol_name = "security_file_mprotect",
	.entry_handler  = mprot_entry,
	.handler        = mprot_ret,
	.data_size      = sizeof(struct mmg_probe_ctx),
	.maxactive      = 256,  /* instancias simultaneas; si se agotan, nmissed++ */
};

/* ---- kprobes 3 y 4: auditoria de page faults de archivo ----------------------
 *  vm_fault_t filemap_fault(struct vm_fault *vmf)
 *  vm_fault_t filemap_map_pages(struct vm_fault *vmf, pgoff_t start, pgoff_t end)
 *
 * HALLAZGO EXPERIMENTAL (VM de validacion, kernel 6.17): con la sola kprobe en
 * filemap_fault se auditaron 0 de 64 paginas tocadas. Motivo: en do_read_fault()
 * el kernel intenta PRIMERO el "fault-around" (vm_ops->map_pages ==
 * filemap_map_pages), que instala en lote las PTE de las paginas que YA estan en
 * el Page Cache y retorna sin llamar nunca a ->fault. Solo una pagina ausente de
 * la cache (o un fallo de escritura compartida) llega a filemap_fault.
 * Por eso se instrumentan ambas rutas. Aun asi, tras instalar la PTE los accesos
 * ya no generan eventos: esa es la ceguera que el enunciado describe y que la
 * boveda (mmguard_vault.c) resuelve controlando ella misma la tabla de paginas. */
static void fault_audit(struct vm_fault *vmf, const char *why)
{
	struct file *file;
	struct mmg_rule *r;

	if (!atomic_read(&mmg_nrules))
		return;
	file = vmf->vma ? vmf->vma->vm_file : NULL;
	rcu_read_lock();
	r = mmg_lookup_rcu(file);
	if (r && (r->flags & MMG_F_AUDIT)) {
		atomic64_inc(&r->faults);
		atomic64_inc(&mmg_stats.faults_audited);
		mmg_audit(MMG_EV_FAULT, false, r->ino, vmf->pgoff, vmf->flags, why);
	}
	rcu_read_unlock();
}

static int fault_pre(struct kprobe *p, struct pt_regs *regs)
{
	struct vm_fault *vmf = (struct vm_fault *)regs_get_kernel_argument(regs, 0);

	fault_audit(vmf, (vmf->flags & FAULT_FLAG_WRITE) ? "fault_write" : "fault_read");
	return 0;
}

static int map_pages_pre(struct kprobe *p, struct pt_regs *regs)
{
	fault_audit((struct vm_fault *)regs_get_kernel_argument(regs, 0), "fault_around");
	return 0;
}

static struct kprobe mmg_kp_fault = {
	.symbol_name = "filemap_fault",
	.pre_handler = fault_pre,
};
static struct kprobe mmg_kp_map_pages = {
	.symbol_name = "filemap_map_pages",
	.pre_handler = map_pages_pre,
};
static bool mmg_fault_probe_ok, mmg_map_pages_probe_ok;

/* ------------------------------------------------------------------------- */
/* Administracion de reglas (/proc/mmguard/policy)                           */
/* ------------------------------------------------------------------------- */
static u32 mmg_parse_flags(const char *s)
{
	u32 f = 0;

	for (; *s; s++) {
		switch (*s) {
		case 'a': f |= MMG_F_AUDIT; break;
		case 's': f |= MMG_F_NO_SHARED_WRITE; break;
		case 'p': f |= MMG_F_NO_PRIVATE_WRITE; break;
		case 'x': f |= MMG_F_NO_EXEC; break;
		case 'd': f |= MMG_F_DENY_ALL; break;
		default:  return 0;
		}
	}
	return f;
}

static int mmg_resolve(const char *path, dev_t *dev, unsigned long *ino)
{
	struct path p;
	struct inode *inode;
	int err = kern_path(path, LOOKUP_FOLLOW, &p);

	if (err)
		return err;
	inode = d_backing_inode(p.dentry);
	*dev = inode->i_sb->s_dev;
	*ino = inode->i_ino;
	path_put(&p);
	return 0;
}

static int mmg_rule_add(const char *path, const char *letters, const char *uid_s)
{
	struct mmg_rule *r, *old;
	unsigned int uid;
	int err;

	r = kzalloc(sizeof(*r), GFP_KERNEL);
	if (!r)
		return -ENOMEM;
	r->flags = mmg_parse_flags(letters);
	if (!r->flags) {
		err = -EINVAL;
		goto fail;
	}
	if (uid_s) {
		err = kstrtouint(uid_s, 10, &uid);
		if (err)
			goto fail;
		r->allow_uid = make_kuid(current_user_ns(), uid);
		if (!uid_valid(r->allow_uid)) {
			err = -EINVAL;
			goto fail;
		}
		r->has_uid = true;
	}
	err = mmg_resolve(path, &r->dev, &r->ino);
	if (err)
		goto fail;
	strscpy(r->path, path, sizeof(r->path));

	mutex_lock(&mmg_rules_lock);
	/* Reemplazo atomico si el inodo ya tenia regla. */
	list_for_each_entry(old, &mmg_rules, list) {
		if (old->ino == r->ino && old->dev == r->dev) {
			list_replace_rcu(&old->list, &r->list);
			kfree_rcu(old, rcu);
			goto done;
		}
	}
	list_add_tail_rcu(&r->list, &mmg_rules);
	atomic_inc(&mmg_nrules);
done:
	mutex_unlock(&mmg_rules_lock);
	mmg_audit(MMG_EV_POLICY, false, r->ino, r->flags, 0, "add");
	return 0;
fail:
	kfree(r);
	return err;
}

static int mmg_rule_del(const char *path)
{
	struct mmg_rule *r;
	unsigned long ino;
	dev_t dev;
	int err = mmg_resolve(path, &dev, &ino);

	if (err)
		return err;
	err = -ENOENT;
	mutex_lock(&mmg_rules_lock);
	list_for_each_entry(r, &mmg_rules, list) {
		if (r->ino == ino && r->dev == dev) {
			list_del_rcu(&r->list);
			atomic_dec(&mmg_nrules);
			kfree_rcu(r, rcu);
			err = 0;
			break;
		}
	}
	mutex_unlock(&mmg_rules_lock);
	if (!err)
		mmg_audit(MMG_EV_POLICY, false, ino, 0, 0, "del");
	return err;
}

static void mmg_rules_clear(void)
{
	struct mmg_rule *r, *tmp;

	mutex_lock(&mmg_rules_lock);
	list_for_each_entry_safe(r, tmp, &mmg_rules, list) {
		list_del_rcu(&r->list);
		kfree_rcu(r, rcu);
	}
	atomic_set(&mmg_nrules, 0);
	mutex_unlock(&mmg_rules_lock);
}

/** Interpreta un comando de /proc/mmguard/policy (contexto de proceso). */
ssize_t mmg_policy_write(const char *cmd)
{
	char *buf, *cur, *argv[4] = { NULL };
	int argc = 0, err;

	buf = kstrdup(cmd, GFP_KERNEL);
	if (!buf)
		return -ENOMEM;
	cur = strim(buf);
	while (cur && *cur && argc < 4) {
		char *tok = strsep(&cur, " \t");

		if (*tok)
			argv[argc++] = tok;
	}

	if (argc >= 3 && !strcmp(argv[0], "add"))
		err = mmg_rule_add(argv[1], argv[2], argc == 4 ? argv[3] : NULL);
	else if (argc == 2 && !strcmp(argv[0], "del"))
		err = mmg_rule_del(argv[1]);
	else if (argc == 1 && !strcmp(argv[0], "clear")) {
		mmg_rules_clear();
		err = 0;
	} else if (argc == 2 && !strcmp(argv[0], "wx")) {
		WRITE_ONCE(mmg_wx_deny, argv[1][0] == '1');
		mmg_audit(MMG_EV_POLICY, false, 0, argv[1][0] == '1', 0, "wx");
		err = 0;
	} else
		err = -EINVAL;

	kfree(buf);
	return err;
}

int mmg_policy_show(struct seq_file *m, void *v)
{
	struct mmg_rule *r;

	seq_printf(m, "# modo=%s  wx=%d  probe_filemap_fault=%s  probe_fault_around=%s\n",
		   READ_ONCE(mmg_enforce) ? "enforcing" : "permissive",
		   READ_ONCE(mmg_wx_deny), mmg_fault_probe_ok ? "activo" : "inactivo",
		   mmg_map_pages_probe_ok ? "activo" : "inactivo");
	seq_puts(m, "# dev:inode            banderas  uid    mmaps   denegados faults  ruta\n");
	rcu_read_lock();
	list_for_each_entry_rcu(r, &mmg_rules, list) {
		char fl[6];
		int i = 0;

		if (r->flags & MMG_F_AUDIT)            fl[i++] = 'a';
		if (r->flags & MMG_F_NO_SHARED_WRITE)  fl[i++] = 's';
		if (r->flags & MMG_F_NO_PRIVATE_WRITE) fl[i++] = 'p';
		if (r->flags & MMG_F_NO_EXEC)          fl[i++] = 'x';
		if (r->flags & MMG_F_DENY_ALL)         fl[i++] = 'd';
		fl[i] = '\0';
		seq_printf(m, "%u:%u:%-12lu  %-8s  %-5d  %-7lld %-9lld %-7lld %s\n",
			   MAJOR(r->dev), MINOR(r->dev), r->ino, fl,
			   r->has_uid ? (int)from_kuid(&init_user_ns, r->allow_uid) : -1,
			   atomic64_read(&r->mmaps), atomic64_read(&r->denials),
			   atomic64_read(&r->faults), r->path);
	}
	rcu_read_unlock();
	return 0;
}

int mmg_policy_init(void)
{
	int err;

	err = register_kretprobe(&mmg_krp_mmap);
	if (err) {
		pr_err(MMG_NAME ": no se pudo registrar kretprobe en %s (%d)\n",
		       mmg_krp_mmap.kp.symbol_name, err);
		return err;
	}
	err = register_kretprobe(&mmg_krp_mprotect);
	if (err) {
		pr_err(MMG_NAME ": no se pudo registrar kretprobe en %s (%d)\n",
		       mmg_krp_mprotect.kp.symbol_name, err);
		unregister_kretprobe(&mmg_krp_mmap);
		return err;
	}
	/* La auditoria de page faults es opcional: si el simbolo no existe en este
	 * kernel (p.ej. inlining), el modulo sigue funcionando sin ella. */
	mmg_fault_probe_ok = register_kprobe(&mmg_kp_fault) == 0;
	mmg_map_pages_probe_ok = register_kprobe(&mmg_kp_map_pages) == 0;
	if (!mmg_fault_probe_ok || !mmg_map_pages_probe_ok)
		pr_warn(MMG_NAME ": auditoria de #PF parcial (filemap_fault=%d, filemap_map_pages=%d)\n",
			mmg_fault_probe_ok, mmg_map_pages_probe_ok);

	pr_info(MMG_NAME ": ganchos activos en security_mmap_file y security_file_mprotect\n");
	return 0;
}

void mmg_policy_exit(void)
{
	if (mmg_map_pages_probe_ok)
		unregister_kprobe(&mmg_kp_map_pages);
	if (mmg_fault_probe_ok)
		unregister_kprobe(&mmg_kp_fault);
	unregister_kretprobe(&mmg_krp_mprotect);
	unregister_kretprobe(&mmg_krp_mmap);
	if (mmg_krp_mmap.nmissed || mmg_krp_mprotect.nmissed)
		pr_warn(MMG_NAME ": instancias de kretprobe perdidas: mmap=%d mprotect=%d\n",
			mmg_krp_mmap.nmissed, mmg_krp_mprotect.nmissed);
	mmg_rules_clear();
	/* Espera a que terminen todos los kfree_rcu() pendientes antes de que el
	 * codigo del modulo desaparezca de memoria. */
	rcu_barrier();
}
