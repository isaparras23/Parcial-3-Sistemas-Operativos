// SPDX-License-Identifier: GPL-2.0
/**
 * @file mmguard_main.c
 * @brief Punto de entrada del modulo MMGuard: inicializacion ordenada,
 *        interfaz /proc/mmguard y parametro "enforce".
 * @course Sistemas Operativos - EAFIT 2026-2
 *         Parcial: Seguridad de Archivos mediante Intervencion en la Capa del
 *         Kernel y Mapeo de Memoria (mmap). Basado en SO2026B/USOS/CapaKernel.
 *
 * Uso rapido:
 *   sudo insmod mmguard.ko vault_owner=1000 debug_tamper=1
 *   echo "add /srv/secreto.db asx" | sudo tee /proc/mmguard/policy
 *   cat /proc/mmguard/{policy,stats,log}
 *   echo 0 | sudo tee /sys/module/mmguard/parameters/enforce   # modo permissive
 */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/capability.h>
#include "mmguard.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Equipo SO 2026-2 - Universidad EAFIT");
MODULE_DESCRIPTION("MMGuard: control de acceso, auditoria y cifrado transparente para regiones mmap()");
MODULE_VERSION("1.0");

bool mmg_enforce = true;
module_param_named(enforce, mmg_enforce, bool, 0644);
MODULE_PARM_DESC(enforce, "1=aplica la politica (enforcing), 0=solo registra (permissive)");

static struct proc_dir_entry *mmg_proc_dir;

/* ---- /proc/mmguard/policy : lectura (seq_file) + escritura de comandos ---- */
static int policy_open(struct inode *inode, struct file *file)
{
	return single_open(file, mmg_policy_show, NULL);
}

static ssize_t policy_write(struct file *file, const char __user *ubuf,
			    size_t len, loff_t *ppos)
{
	char *kbuf;
	ssize_t ret;

	if (!capable(CAP_SYS_ADMIN))
		return -EPERM;
	if (len == 0 || len > 512)
		return -EINVAL;
	kbuf = memdup_user_nul(ubuf, len);
	if (IS_ERR(kbuf))
		return PTR_ERR(kbuf);
	ret = mmg_policy_write(kbuf);
	kfree(kbuf);
	return ret ? ret : (ssize_t)len;
}

static const struct proc_ops policy_ops = {
	.proc_open    = policy_open,
	.proc_read    = seq_read,
	.proc_lseek   = seq_lseek,
	.proc_release = single_release,
	.proc_write   = policy_write,
};

static int __init mmguard_init(void)
{
	int err;

	err = mmg_audit_init();
	if (err)
		return err;

	err = mmg_vault_init();
	if (err)
		goto err_audit;

	mmg_proc_dir = proc_mkdir(MMG_NAME, NULL);
	if (!mmg_proc_dir) {
		err = -ENOMEM;
		goto err_vault;
	}
	if (!proc_create("policy", 0600, mmg_proc_dir, &policy_ops) ||
	    !proc_create_single("stats", 0444, mmg_proc_dir, mmg_stats_show) ||
	    !proc_create_single("log", 0400, mmg_proc_dir, mmg_audit_show)) {
		err = -ENOMEM;
		goto err_proc;
	}

	/* Los ganchos se activan al FINAL: cuando empiezan a dispararse, todo lo
	 * que usan (auditoria, procfs) ya existe. */
	err = mmg_policy_init();
	if (err)
		goto err_proc;

	pr_info(MMG_NAME ": cargado (modo %s)\n", mmg_enforce ? "enforcing" : "permissive");
	return 0;

err_proc:
	proc_remove(mmg_proc_dir);
err_vault:
	mmg_vault_exit();
err_audit:
	mmg_audit_exit();
	return err;
}

static void __exit mmguard_exit(void)
{
	/* Orden inverso: primero se retiran los ganchos (ya nadie entra a nuestro
	 * codigo desde la ruta de mmap), luego las interfaces. */
	mmg_policy_exit();
	proc_remove(mmg_proc_dir);
	mmg_vault_exit();
	mmg_audit_exit();
	pr_info(MMG_NAME ": descargado\n");
}

module_init(mmguard_init);
module_exit(mmguard_exit);
