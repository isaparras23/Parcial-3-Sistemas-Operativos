/* SPDX-License-Identifier: GPL-2.0 */
/**
 * @file mmguard.h
 * @brief Declaraciones internas del modulo MMGuard.
 *
 * Arquitectura:
 *
 *   +--------------------------- mmguard.ko --------------------------------+
 *   |  mmguard_main.c   : init/exit, /proc/mmguard/{policy,stats,log}       |
 *   |  mmguard_policy.c : kretprobe security_mmap_file      (alta del VMA)  |
 *   |                     kretprobe security_file_mprotect  (cambio de prot)|
 *   |                     kprobe    filemap_fault           (auditoria #PF) |
 *   |                     kprobe    filemap_map_pages       (fault-around)  |
 *   |  mmguard_vault.c  : /dev/mmvault  AES-256-CTR + HMAC-SHA256,          |
 *   |                     vm_ops->fault descifra pagina a pagina            |
 *   |  mmguard_audit.c  : anillo de auditoria + contadores atomicos         |
 *   +-----------------------------------------------------------------------+
 */
#ifndef MMGUARD_H
#define MMGUARD_H

#include <linux/types.h>
#include <linux/atomic.h>
#include <linux/seq_file.h>
#include "mmguard_uapi.h"

#define MMG_NAME "mmguard"

/* Parametro global: 1 = aplicar (enforcing), 0 = solo auditar (permissive). */
extern bool mmg_enforce;

/* ------------------------- Auditoria ------------------------------------ */
enum mmg_event {
	MMG_EV_MMAP = 1,       /* alta de VMA sobre archivo protegido          */
	MMG_EV_MPROTECT,       /* cambio de permisos de un VMA protegido        */
	MMG_EV_FAULT,          /* page fault sobre archivo con bandera 'a'      */
	MMG_EV_WX,             /* violacion de la politica W^X                  */
	MMG_EV_VAULT_MMAP,     /* proyeccion de la boveda                       */
	MMG_EV_VAULT_DENY,     /* acceso no autorizado a la boveda              */
	MMG_EV_VAULT_WRITEBACK,/* pagina modificada y re-cifrada                */
	MMG_EV_VAULT_TAMPER,   /* HMAC invalido: almacenamiento alterado        */
	MMG_EV_POLICY,         /* cambio de politica                            */
};

struct mmg_stats {
	atomic64_t mmap_checked;
	atomic64_t mmap_denied;
	atomic64_t mprotect_checked;
	atomic64_t mprotect_denied;
	atomic64_t faults_audited;
	atomic64_t wx_denied;
	atomic64_t audit_only;      /* violaciones registradas en modo permissive */
	atomic64_t check_ns_total;  /* tiempo acumulado de la decision de politica */
	atomic64_t check_ns_max;
	atomic64_t vault_faults;
	atomic64_t vault_writebacks;
	atomic64_t vault_tamper;
	atomic64_t vault_denied;
};
extern struct mmg_stats mmg_stats;

int  mmg_audit_init(void);
void mmg_audit_exit(void);
void mmg_audit(enum mmg_event ev, bool denied, unsigned long ino,
	       unsigned long prot, unsigned long flags, const char *why);
int  mmg_audit_show(struct seq_file *m, void *v);
int  mmg_stats_show(struct seq_file *m, void *v);
void mmg_stats_add_time(u64 ns);

/* ------------------------- Politica ------------------------------------- */
int     mmg_policy_init(void);
void    mmg_policy_exit(void);
int     mmg_policy_show(struct seq_file *m, void *v);
ssize_t mmg_policy_write(const char *cmd);

/* ------------------------- Boveda --------------------------------------- */
int  mmg_vault_init(void);
void mmg_vault_exit(void);
int  mmg_vault_show(struct seq_file *m);

#endif /* MMGUARD_H */
