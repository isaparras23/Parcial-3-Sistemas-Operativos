/* SPDX-License-Identifier: GPL-2.0 */
/**
 * @file mmguard_uapi.h
 * @brief Interfaz compartida (kernel <-> espacio de usuario) del proyecto MMGuard.
 * @course Sistemas Operativos - EAFIT 2026-2 - Parcial: Seguridad en capa kernel y mmap
 *
 * Este header se incluye tanto desde el modulo de kernel (carpeta kernel/) como
 * desde los programas de prueba (carpeta tests/). Por eso solo usa tipos de <linux/types.h>
 * (__u32, __u64) y macros de <linux/ioctl.h>, que existen en ambos mundos.
 *
 * Componentes expuestos:
 *   1. Banderas de politica para /proc/mmguard/policy (control de mmap/mprotect).
 *   2. ioctl() del dispositivo /dev/mmvault (boveda cifrada proyectable con mmap).
 */
#ifndef MMGUARD_UAPI_H
#define MMGUARD_UAPI_H

#include <linux/types.h>
#include <linux/ioctl.h>

/* ------------------------------------------------------------------------- */
/* 1. Politica de proteccion de archivos (gancho sobre security_mmap_file)    */
/* ------------------------------------------------------------------------- */
/*
 * Sintaxis de escritura en /proc/mmguard/policy (solo root / CAP_SYS_ADMIN):
 *
 *     add <ruta> <letras> [uid]   -> protege el inodo al que apunta <ruta>
 *     del <ruta>                  -> elimina la regla
 *     clear                       -> elimina todas las reglas
 *     wx <0|1>                    -> politica global W^X (anti inyeccion de codigo)
 *
 * Letras (se combinan, p.ej. "asx"):
 *     a  MMG_F_AUDIT             registrar cada mmap/mprotect/page fault del archivo
 *     s  MMG_F_NO_SHARED_WRITE   prohibir MAP_SHARED + PROT_WRITE (integridad en disco)
 *     p  MMG_F_NO_PRIVATE_WRITE  prohibir MAP_PRIVATE + PROT_WRITE (copias COW alteradas)
 *     x  MMG_F_NO_EXEC           prohibir PROT_EXEC (el archivo no puede ser codigo)
 *     d  MMG_F_DENY_ALL          prohibir cualquier mmap salvo al [uid] autorizado
 */
#define MMG_F_AUDIT             0x01u
#define MMG_F_NO_SHARED_WRITE   0x02u
#define MMG_F_NO_PRIVATE_WRITE  0x04u
#define MMG_F_NO_EXEC           0x08u
#define MMG_F_DENY_ALL          0x10u

#define MMG_PROC_DIR     "/proc/mmguard"
#define MMG_PROC_POLICY  "/proc/mmguard/policy"
#define MMG_PROC_STATS   "/proc/mmguard/stats"
#define MMG_PROC_LOG     "/proc/mmguard/log"
#define MMG_PARAM_ENFORCE "/sys/module/mmguard/parameters/enforce"

/* ------------------------------------------------------------------------- */
/* 2. Boveda cifrada /dev/mmvault                                             */
/* ------------------------------------------------------------------------- */
#define MMV_DEVICE      "/dev/mmvault"
#define MMV_IOC_MAGIC   'V'

/** Estado publico de la boveda (nunca incluye material de clave). */
struct mmv_info {
	__u32 page_size;        /* PAGE_SIZE del kernel                         */
	__u32 npages;           /* capacidad de la boveda en paginas            */
	__u64 data_len;         /* bytes logicos escritos                       */
	__u32 owner_uid;        /* unico uid autorizado a descifrar             */
	__u32 active_maps;      /* proyecciones mmap vivas                      */
	__u64 faults;           /* fallos de pagina atendidos (descifrados)     */
	__u64 writebacks;       /* paginas re-cifradas al hacer munmap          */
	__u64 tamper;           /* paginas con HMAC invalido detectadas         */
	__u64 denied;           /* accesos denegados por control de acceso      */
};

/** Exporta el texto CIFRADO de una pagina (lo que "veria el disco"). */
struct mmv_cipher_req {
	__u32 page;             /* indice de pagina                             */
	__u32 version;          /* (salida) version usada en el IV de AES-CTR   */
	__u64 buf;              /* puntero de usuario a un buffer de page_size  */
};

#define MMV_IOC_INFO            _IOR(MMV_IOC_MAGIC, 1, struct mmv_info)
#define MMV_IOC_GET_CIPHER      _IOWR(MMV_IOC_MAGIC, 2, struct mmv_cipher_req)
/* Solo disponible con el parametro debug_tamper=1: simula un atacante que
 * altera el almacenamiento cifrado (disco/memoria offline). */
#define MMV_IOC_DEBUG_CORRUPT   _IOW(MMV_IOC_MAGIC, 3, __u32)
#define MMV_IOC_WIPE            _IO(MMV_IOC_MAGIC, 4)

#endif /* MMGUARD_UAPI_H */
