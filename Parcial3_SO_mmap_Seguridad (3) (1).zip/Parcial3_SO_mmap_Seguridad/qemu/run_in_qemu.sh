#!/bin/bash
# =============================================================================
# run_in_qemu.sh - Entorno de validacion AISLADO para el modulo de kernel.
#
# Un bug en un LKM puede producir un kernel panic. Por eso la bateria completa
# se ejecuta primero en una VM QEMU desechable que arranca un kernel Ubuntu
# real (6.x) con un initramfs minimo (busybox + binarios estaticos + mmguard.ko).
# Si la VM muere, el equipo de desarrollo no se ve afectado.
#
#   ./qemu/run_in_qemu.sh /boot/vmlinuz-6.17.0-42-generic /usr/src/linux-headers-6.17.0-42-generic
#
# Requisitos (Ubuntu): qemu-system-x86 busybox-static linux-image-<ver> linux-headers-<ver>
# Variables: BPFTRACE=1 incluye bpftrace en la VM para validar ebpf/mmap_audit.bt
#            MODE=tests solo ejecuta la bateria de pruebas (sin eBPF ni benchmark)
#            MODE=ebpf  solo ejecuta la demo eBPF (requiere BPFTRACE=1)
#            KCC=gcc-11 compilador para el modulo (debe coincidir con el del kernel)
# =============================================================================
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
VMLINUZ=${1:?uso: $0 <vmlinuz> <kdir>}
KDIR=${2:?uso: $0 <vmlinuz> <kdir>}
WORK=$(mktemp -d)
IRD="$WORK/initramfs"
LOG="$ROOT/resultados/qemu_run.log"
trap 'rm -rf "$WORK"' EXIT

echo "[*] Compilando modulo contra $KDIR y binarios estaticos"
make -C "$ROOT/kernel" KDIR="$KDIR" CC="${KCC:-gcc}" >/dev/null
make -C "$ROOT" user STATIC=-static >/dev/null

echo "[*] Construyendo initramfs"
mkdir -p "$IRD"/{bin,sbin,proc,sys,dev,tmp,data,opt/mmguard,etc,lib64,usr/lib}
cp /bin/busybox "$IRD/bin/busybox"
for d in kernel tests bench bypass_userspace scripts ebpf include; do
	mkdir -p "$IRD/opt/mmguard/$d"
done
cp "$ROOT"/kernel/mmguard.ko "$IRD/opt/mmguard/kernel/"
cp "$ROOT"/tests/test_{policy,vault,semantica,race,wx} "$IRD/opt/mmguard/tests/"
cp "$ROOT"/bench/bench_mmap "$IRD/opt/mmguard/bench/"
cp "$ROOT"/bypass_userspace/{bypass_demo,preload_guard.so} "$IRD/opt/mmguard/bypass_userspace/"
cp "$ROOT"/scripts/*.sh "$IRD/opt/mmguard/scripts/"
cp "$ROOT"/ebpf/*.bt "$IRD/opt/mmguard/ebpf/"

# Bibliotecas dinamicas (demo LD_PRELOAD y, opcionalmente, bpftrace)
copy_deps() {
	for lib in $(ldd "$1" 2>/dev/null | grep -o '/[^ ]*'); do
		mkdir -p "$IRD$(dirname "$lib")"
		cp -nL "$lib" "$IRD$lib" 2>/dev/null || true
	done
}
copy_deps "$ROOT/bypass_userspace/bypass_demo"
copy_deps "$ROOT/bypass_userspace/preload_guard.so"
if command -v strace >/dev/null; then
	cp "$(command -v strace)" "$IRD/bin/"
	copy_deps "$(command -v strace)"
fi
if [ "${BPFTRACE:-0}" = 1 ] && command -v bpftrace >/dev/null; then
	cp "$(command -v bpftrace)" "$IRD/bin/"
	copy_deps "$(command -v bpftrace)"
fi

cp /etc/ld.so.cache "$IRD/etc/" 2>/dev/null || true

cat > "$IRD/init" <<'EOF'
#!/bin/busybox sh
/bin/busybox --install -s /bin
mount -t proc proc /proc
mount -t sysfs sys /sys
mount -t devtmpfs dev /dev
mount -t tmpfs tmp /tmp
mount -t ramfs data /data          # ramfs usa filemap_fault (generic_file_vm_ops)
mount -t debugfs none /sys/kernel/debug 2>/dev/null
mount -t tracefs none /sys/kernel/tracing 2>/dev/null
ulimit -l unlimited
export LD_LIBRARY_PATH=/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu
echo "========== VM de validacion: $(uname -r) =========="
cd /opt/mmguard && mkdir -p resultados
if [ "${MODE:-full}" != ebpf ]; then
TESTDIR=/data RACE_SECS=${RACE_SECS:-3} sh scripts/run_all_tests.sh
echo "========== FIN PRUEBAS rc=$? =========="
fi
[ "${MODE:-full}" = tests ] && poweroff -f
if [ -x /bin/bpftrace ]; then
	echo "========== eBPF: ebpf/mmap_audit.bt =========="
	insmod kernel/mmguard.ko vault_owner=0
	TESTDIR=/data bpftrace ebpf/mmap_audit.bt -c "sh scripts/ebpf_workload.sh" 2>&1 \
		| grep -E 'Attaching|HORA|ALERTA|DENEGADO|RACE|MMAP .*(secreto|solo_lectura)|^@|^\[|Resumen' \
		| head -n 150 | tee resultados/ebpf_audit.txt
	rmmod mmguard
	echo "========== FIN eBPF =========="
fi
[ "${MODE:-full}" = ebpf ] && poweroff -f
echo "========== BENCHMARK =========="
TESTDIR=/data ITERS=${ITERS:-20000} sh scripts/run_bench.sh
echo "========== FIN BENCHMARK =========="
cat resultados/*.csv 2>/dev/null | sed 's/^/CSV:/'
poweroff -f
EOF
chmod +x "$IRD/init"
(cd "$IRD" && find . | cpio -o -H newc 2>/dev/null | gzip -1) > "$WORK/initramfs.gz"
echo "[*] initramfs: $(du -h "$WORK/initramfs.gz" | cut -f1)"

ACCEL=tcg
[ -w /dev/kvm ] && ACCEL=kvm
echo "[*] Arrancando QEMU (accel=$ACCEL); salida en $LOG"
mkdir -p "$ROOT/resultados"
timeout "${QEMU_TIMEOUT:-3000}" qemu-system-x86_64 -accel "$ACCEL" -cpu max -smp 2 -m 3072 \
	-kernel "$VMLINUZ" -initrd "$WORK/initramfs.gz" \
	-append "console=ttyS0 quiet loglevel=4 panic=-1 oops=panic init=/init MODE=${MODE:-full}" \
	-nographic -no-reboot 2>&1 | tee "$LOG"
