/**
 * @file bench_mmap.c
 * @brief Micro-benchmark del sobrecosto (overhead) que introduce MMGuard en:
 *        (1) la llamada mmap()+munmap()   -> pasa por security_mmap_file
 *        (2) mprotect()                   -> pasa por security_file_mprotect
 *        (3) la atencion de page faults de archivo (filemap_fault auditado)
 *        (4) page faults de la boveda cifrada (descifrado AES-CTR + HMAC)
 *
 * Uso: ./bench_mmap <dir> <etiqueta> [iteraciones]
 * Salida: lineas CSV "etiqueta,metrica,valor_ns" faciles de comparar.
 */
#include "../tests/common.h"
#include <sys/resource.h>

static long PG;

static int cmp_d(const void *a, const void *b)
{
	double x = *(const double *)a, y = *(const double *)b;

	return (x > y) - (x < y);
}

/* Mediana de 'reps' repeticiones de un lote, para filtrar ruido del planificador. */
#define REPS 7

static long faults(void)
{
	struct rusage ru;

	getrusage(RUSAGE_SELF, &ru);
	return ru.ru_minflt + ru.ru_majflt;
}

int main(int argc, char **argv)
{
	const char *dir = argc > 1 ? argv[1] : "/tmp/mmguard_test";
	const char *tag = argc > 2 ? argv[2] : "base";
	int iters = argc > 3 ? atoi(argv[3]) : 20000;
	double res[REPS], t0;
	char path[300];
	int fd, r, i;
	const int NPG = 256;

	PG = sysconf(_SC_PAGESIZE);
	mkdir(dir, 0755);
	snprintf(path, sizeof(path), "%s/bench.bin", dir);
	fd = open(path, O_CREAT | O_RDWR, 0644);
	if (fd < 0 || ftruncate(fd, (off_t)NPG * PG)) {
		perror(path);
		return 2;
	}

	/* (1) mmap + munmap de 1 pagina */
	for (r = 0; r < REPS; r++) {
		t0 = now_ns();
		for (i = 0; i < iters; i++) {
			void *p = mmap(NULL, PG, PROT_READ, MAP_SHARED, fd, 0);

			munmap(p, PG);
		}
		res[r] = (now_ns() - t0) / iters;
	}
	qsort(res, REPS, sizeof(double), cmp_d);
	printf("%s,mmap_munmap_ns,%.1f\n", tag, res[REPS / 2]);

	/* (2) mprotect R <-> R (misma proteccion: aisla el costo del gancho) */
	{
		void *p = mmap(NULL, PG, PROT_READ, MAP_PRIVATE, fd, 0);

		for (r = 0; r < REPS; r++) {
			t0 = now_ns();
			for (i = 0; i < iters; i++)
				mprotect(p, PG, (i & 1) ? PROT_READ : PROT_NONE);
			res[r] = (now_ns() - t0) / iters;
		}
		qsort(res, REPS, sizeof(double), cmp_d);
		printf("%s,mprotect_ns,%.1f\n", tag, res[REPS / 2]);
		munmap(p, PG);
	}

	/* (3) page faults de archivo (lectura): mapear, tocar 256 paginas, desmapear */
	{
		long nf = 0;
		int rounds = iters / 200 > 10 ? iters / 200 : 10;

		for (r = 0; r < REPS; r++) {
			long f0 = faults();

			t0 = now_ns();
			for (i = 0; i < rounds; i++) {
				volatile char *p = mmap(NULL, (size_t)NPG * PG, PROT_READ, MAP_SHARED, fd, 0);

				for (int k = 0; k < NPG; k++)
					(void)p[(size_t)k * PG];
				munmap((void *)p, (size_t)NPG * PG);
			}
			nf = faults() - f0;
			res[r] = (now_ns() - t0) / (nf ? nf : 1);
		}
		qsort(res, REPS, sizeof(double), cmp_d);
		printf("%s,file_fault_read_ns,%.1f\n", tag, res[REPS / 2]);
		printf("%s,file_faults_por_256pag,%.1f\n", tag, (double)nf / rounds);
	}

	/* (3b) page faults de escritura compartida (sin fault-around) */
	{
		int rounds = iters / 200 > 10 ? iters / 200 : 10;

		for (r = 0; r < REPS; r++) {
			long f0 = faults(), nf;

			t0 = now_ns();
			for (i = 0; i < rounds; i++) {
				char *p = mmap(NULL, (size_t)NPG * PG, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

				for (int k = 0; k < NPG; k++)
					p[(size_t)k * PG] = (char)k;
				munmap(p, (size_t)NPG * PG);
			}
			nf = faults() - f0;
			res[r] = (now_ns() - t0) / (nf ? nf : 1);
		}
		qsort(res, REPS, sizeof(double), cmp_d);
		printf("%s,file_fault_write_ns,%.1f\n", tag, res[REPS / 2]);
	}

	/* (4) boveda: costo por page fault descifrado (incluye re-cifrado/borrado en munmap) */
	{
		int vfd = open("/dev/mmvault", O_RDWR);

		if (vfd >= 0) {
			const int VP = 16;
			int rounds = iters / 400 > 10 ? iters / 400 : 10;

			for (r = 0; r < REPS; r++) {
				t0 = now_ns();
				for (i = 0; i < rounds; i++) {
					volatile char *p = mmap(NULL, (size_t)VP * PG, PROT_READ, MAP_SHARED, vfd, 0);

					if (p == MAP_FAILED)
						break;
					for (int k = 0; k < VP; k++)
						(void)p[(size_t)k * PG];
					munmap((void *)p, (size_t)VP * PG);
				}
				res[r] = (now_ns() - t0) / ((double)rounds * VP);
			}
			qsort(res, REPS, sizeof(double), cmp_d);
			printf("%s,vault_fault_read_ns,%.1f\n", tag, res[REPS / 2]);

			for (r = 0; r < REPS; r++) {
				t0 = now_ns();
				for (i = 0; i < rounds; i++) {
					char *p = mmap(NULL, (size_t)VP * PG, PROT_READ | PROT_WRITE, MAP_SHARED, vfd, 0);

					if (p == MAP_FAILED)
						break;
					for (int k = 0; k < VP; k++)
						p[(size_t)k * PG] ^= 1;   /* fuerza re-cifrado al munmap */
					munmap(p, (size_t)VP * PG);
				}
				res[r] = (now_ns() - t0) / ((double)rounds * VP);
			}
			qsort(res, REPS, sizeof(double), cmp_d);
			printf("%s,vault_fault_rw_writeback_ns,%.1f\n", tag, res[REPS / 2]);
			close(vfd);
		}
	}

	/* referencia: fault anonimo */
	{
		int rounds = iters / 200 > 10 ? iters / 200 : 10;

		for (r = 0; r < REPS; r++) {
			long f0 = faults(), nf;

			t0 = now_ns();
			for (i = 0; i < rounds; i++) {
				char *p = mmap(NULL, (size_t)NPG * PG, PROT_READ | PROT_WRITE,
					       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

				for (int k = 0; k < NPG; k++)
					p[(size_t)k * PG] = 1;
				munmap(p, (size_t)NPG * PG);
			}
			nf = faults() - f0;
			res[r] = (now_ns() - t0) / (nf ? nf : 1);
		}
		qsort(res, REPS, sizeof(double), cmp_d);
		printf("%s,anon_fault_ns,%.1f\n", tag, res[REPS / 2]);
	}
	close(fd);
	return 0;
}
