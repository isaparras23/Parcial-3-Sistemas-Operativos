/**
 * @file preload_guard.c
 * @brief "Defensa" INGENUA en espacio de usuario (LD_PRELOAD) que intenta
 *        impedir mmap(PROT_WRITE) sobre archivos "secretos". Existe para
 *        DEMOSTRAR por que la defensa no puede vivir en Ring 3.
 *
 * Compilar: gcc -shared -fPIC -o preload_guard.so preload_guard.c -ldl
 * Usar:     LD_PRELOAD=./preload_guard.so ./bypass_demo archivo
 */
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

void *mmap(void *addr, size_t len, int prot, int flags, int fd, off_t off)
{
	static void *(*real_mmap)(void *, size_t, int, int, int, off_t);
	char link[64], target[512];
	ssize_t n;

	if (!real_mmap)
		real_mmap = dlsym(RTLD_NEXT, "mmap");
	if (fd >= 0 && (prot & PROT_WRITE)) {
		snprintf(link, sizeof(link), "/proc/self/fd/%d", fd);
		n = readlink(link, target, sizeof(target) - 1);
		if (n > 0) {
			target[n] = '\0';
			if (strstr(target, "secreto")) {
				fprintf(stderr, "[preload_guard] BLOQUEADO mmap(PROT_WRITE) sobre %s\n", target);
				errno = EACCES;
				return MAP_FAILED;
			}
		}
	}
	return real_mmap(addr, len, prot, flags, fd, off);
}
