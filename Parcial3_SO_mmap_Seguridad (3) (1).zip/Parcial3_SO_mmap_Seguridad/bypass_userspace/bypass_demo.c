/**
 * @file bypass_demo.c
 * @brief Atacante que evade la "defensa" LD_PRELOAD con 3 tecnicas triviales.
 *        Con MMGuard cargado (regla 's'), las 3 tecnicas fallan con EACCES,
 *        porque la decision se toma en security_mmap_file() dentro del kernel.
 *
 * Uso: LD_PRELOAD=./preload_guard.so ./bypass_demo <dir>/secreto.txt
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>

static void report(const char *how, void *p)
{
	if (p == MAP_FAILED || p == NULL)
		printf("   %-48s -> BLOQUEADO (%s)\n", how, strerror(errno));
	else {
		printf("   %-48s -> EXITO: mapeo RW compartido en %p\n", how, p);
		munmap(p, 4096);
	}
}

/* Syscall cruda en ensamblador: ni libc ni el loader dinamico intervienen. */
static long raw_mmap(void *a, size_t l, long prot, long fl, long fd, long off)
{
	long ret;
	register long r10 __asm__("r10") = fl;
	register long r8  __asm__("r8")  = fd;
	register long r9  __asm__("r9")  = off;

	__asm__ volatile ("syscall"
			  : "=a"(ret)
			  : "0"(9L /* __NR_mmap x86_64 */), "D"(a), "S"(l), "d"(prot),
			    "r"(r10), "r"(r8), "r"(r9)
			  : "rcx", "r11", "memory");
	return ret;
}

int main(int argc, char **argv)
{
	int fd;
	long r;

	if (argc < 2) {
		fprintf(stderr, "uso: %s <ruta/secreto.txt>\n", argv[0]);
		return 2;
	}
	fd = open(argv[1], O_RDWR);
	if (fd < 0) {
		perror("open");
		return 2;
	}
	printf("Objetivo: mmap(PROT_READ|PROT_WRITE, MAP_SHARED) sobre %s\n", argv[1]);

	report("1) mmap() de libc (interceptado por LD_PRELOAD)",
	       mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0));

	r = syscall(SYS_mmap, NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	report("2) syscall(SYS_mmap) (salta el wrapper)", r == -1 ? MAP_FAILED : (void *)r);

	r = raw_mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if (r < 0 && r > -4096) {
		errno = (int)-r;
		r = -1;
	}
	report("3) instruccion 'syscall' en asm (sin libc)", r == -1 ? MAP_FAILED : (void *)r);

	printf("   4) un binario estatico ignora LD_PRELOAD por completo.\n");
	close(fd);
	return 0;
}
