/**
 * @file test_wx.c
 * @brief Politica W^X de MMGuard contra inyeccion de codigo en memoria
 *        mapeada (pregunta 10). Demuestra primero la AMENAZA (con wx=0 se
 *        ejecuta codigo escrito en tiempo de ejecucion) y luego la DEFENSA.
 *
 * Requiere root y mmguard cargado. Solo x86_64 (usa el opcode 0xC3 = ret).
 */
#include "common.h"

/* "Shellcode" inofensivo: mov eax, 42 ; ret */
static const unsigned char CODE[] = { 0xB8, 0x2A, 0x00, 0x00, 0x00, 0xC3 };

static int exec_payload(void *p)
{
	int (*fn)(void) = (int (*)(void))p;

	return fn();
}

int main(void)
{
	long pg = sysconf(_SC_PAGESIZE);
	void *p;
	int err;

	if (access("/proc/mmguard/policy", W_OK)) {
		fprintf(stderr, "mmguard no cargado o no root\n");
		return 2;
	}
	write_str("/sys/module/mmguard/parameters/enforce", "1");

	SECTION("Amenaza (wx=0): escribir codigo y ejecutarlo");
	policy("wx 0");
	p = mmap(NULL, pg, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	memcpy(p, CODE, sizeof(CODE));
	CHECK(mprotect(p, pg, PROT_READ | PROT_EXEC) == 0, "mprotect(RW -> RX) permitido");
	CHECK(exec_payload(p) == 42, "codigo inyectado ejecutado: devolvio 42");
	munmap(p, pg);

	SECTION("Defensa (wx=1)");
	CHECK(policy("wx 1") == 0, "politica W^X activada");
	err = try_mmap(-1, pg, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS);
	CHECK(err == EACCES, "mmap anonimo RWX -> EACCES");
	p = mmap(NULL, pg, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
	CHECK(p != MAP_FAILED, "mmap anonimo RW sigue permitido (datos normales)");
	memcpy(p, CODE, sizeof(CODE));
	err = mprotect(p, pg, PROT_READ | PROT_EXEC) ? errno : 0;
	CHECK(err == EACCES, "mprotect(RW -> RX) de memoria anonima -> EACCES (shellcode bloqueado)");
	err = mprotect(p, pg, PROT_READ | PROT_WRITE | PROT_EXEC) ? errno : 0;
	CHECK(err == EACCES, "mprotect(RWX) -> EACCES");
	munmap(p, pg);
	policy("wx 0");
	INFO("trade-off: los JIT (V8, JVM, LuaJIT) necesitan W->X; en produccion se exime por uid/ejecutable");
	return finish("test_wx");
}
