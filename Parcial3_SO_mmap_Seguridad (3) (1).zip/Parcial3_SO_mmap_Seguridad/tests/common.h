/**
 * @file common.h
 * @brief Utilidades minimas de prueba (estilo TAP) compartidas por los tests.
 */
#ifndef MMG_TEST_COMMON_H
#define MMG_TEST_COMMON_H

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define C_OK   "\033[0;32m"
#define C_BAD  "\033[0;31m"
#define C_HDR  "\033[1;36m"
#define C_INF  "\033[0;33m"
#define C_END  "\033[0m"

static int g_pass __attribute__((unused)), g_fail __attribute__((unused));

#define SECTION(...) do { printf("\n" C_HDR "== "); printf(__VA_ARGS__); printf(" ==" C_END "\n"); } while (0)
#define INFO(...)    do { printf("   " C_INF "i " C_END); printf(__VA_ARGS__); printf("\n"); } while (0)
#define CHECK(cond, ...) do {                                              \
	if (cond) { g_pass++; printf("  " C_OK "[PASS]" C_END " "); }        \
	else      { g_fail++; printf("  " C_BAD "[FAIL]" C_END " "); }       \
	printf(__VA_ARGS__); printf("\n"); fflush(stdout);                    \
} while (0)

static inline int finish(const char *name)
{
	printf("\n%s: %d PASS, %d FAIL\n", name, g_pass, g_fail);
	return g_fail ? 1 : 0;
}

/** Escribe un comando en un archivo de /proc o /sys (devuelve 0 o -errno). */
static inline int write_str(const char *path, const char *s)
{
	int fd = open(path, O_WRONLY);
	ssize_t n;

	if (fd < 0)
		return -errno;
	n = write(fd, s, strlen(s));
	if (n < 0) {
		int e = errno;
		close(fd);
		return -e;
	}
	close(fd);
	return 0;
}

static inline int policy(const char *fmt, ...)
{
	char cmd[512];
	va_list ap;

	va_start(ap, fmt);
	vsnprintf(cmd, sizeof(cmd), fmt, ap);
	va_end(ap);
	return write_str("/proc/mmguard/policy", cmd);
}

/** Crea un archivo con contenido dado. */
static inline void make_file(const char *path, const char *content, mode_t mode)
{
	int fd = open(path, O_CREAT | O_TRUNC | O_WRONLY, mode);

	if (fd < 0) { perror(path); exit(2); }
	if (write(fd, content, strlen(content)) < 0) { perror("write"); exit(2); }
	close(fd);
	chmod(path, mode);
}

/** Lee el archivo completo (hasta n-1 bytes) por la ruta read() clasica. */
static inline ssize_t slurp(const char *path, char *buf, size_t n)
{
	int fd = open(path, O_RDONLY);
	ssize_t r;

	if (fd < 0)
		return -1;
	r = read(fd, buf, n - 1);
	close(fd);
	if (r >= 0)
		buf[r] = '\0';
	return r;
}

/** Intenta mmap y devuelve 0 si tuvo exito o errno si fallo (y desmapea). */
static inline int try_mmap(int fd, size_t len, int prot, int flags)
{
	void *p = mmap(NULL, len, prot, flags, fd, 0);

	if (p == MAP_FAILED)
		return errno;
	munmap(p, len);
	return 0;
}

static inline double now_ns(void)
{
	struct timespec ts;

	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec * 1e9 + ts.tv_nsec;
}

/** Ejecuta fn() en un hijo y devuelve el status de waitpid (para medir senales). */
static inline int run_in_child(void (*fn)(void *), void *arg)
{
	int st;
	pid_t pid = fork();

	if (pid == 0) {
		fn(arg);
		_exit(0);
	}
	waitpid(pid, &st, 0);
	return st;
}

#endif
