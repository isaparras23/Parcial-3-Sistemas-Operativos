/**
 * @file test_semantica.c
 * @brief Evidencia empirica del comportamiento NATIVO del kernel (sin MMGuard)
 *        que fundamenta las preguntas 1, 2, 3 y 8 del parcial.
 *
 *   - Paginacion por demanda: mmap() no carga nada; el primer acceso causa #PF.
 *   - MAP_SHARED vs MAP_PRIVATE: visibilidad cruzada y persistencia.
 *   - O_RDONLY + PROT_WRITE: SHARED -> EACCES ; PRIVATE -> permitido (COW).
 *   - VM_MAYWRITE: mprotect(PROT_WRITE) imposible en SHARED sobre fd O_RDONLY.
 *
 * Puede ejecutarse como usuario normal. Uso: ./test_semantica [dir]
 */
#include "common.h"
#include <sys/resource.h>

static long minflt(void)
{
	struct rusage ru;

	getrusage(RUSAGE_SELF, &ru);
	return ru.ru_minflt + ru.ru_majflt;
}

int main(int argc, char **argv)
{
	char path[300], buf[128];
	const char *dir = argc > 1 ? argv[1] : "/tmp/mmguard_test";
	long pg = sysconf(_SC_PAGESIZE);
	char *s1, *s2, *pr, *p;
	int fd, ro;

	mkdir(dir, 0755);
	snprintf(path, sizeof(path), "%s/semantica.txt", dir);
	make_file(path, "ORIGINAL-ORIGINAL-ORIGINAL\n", 0644);

	SECTION("Q1. Paginacion por demanda: mmap() solo crea el VMA");
	{
		int big;
		char bpath[300];
		long f0, f1, f2;
		volatile char x = 0;

		snprintf(bpath, sizeof(bpath), "%s/demanda.bin", dir);
		big = open(bpath, O_CREAT | O_TRUNC | O_RDWR, 0644);
		if (ftruncate(big, 256 * pg)) perror("ftruncate");
		f0 = minflt();
		p = mmap(NULL, 256 * pg, PROT_READ, MAP_PRIVATE, big, 0);
		f1 = minflt();
		for (int i = 0; i < 256; i += 32)
			x += p[i * pg];
		f2 = minflt();
		CHECK(f1 - f0 <= 1, "fallos de pagina durante mmap(): %ld (el VMA existe, las PTE no)", f1 - f0);
		CHECK(f2 - f1 >= 1, "fallos al tocar 8 paginas dispersas: %ld", f2 - f1);
		munmap(p, 256 * pg);
		close(big);
		(void)x;
	}

	SECTION("Q2. MAP_SHARED: visibilidad cruzada y persistencia");
	fd = open(path, O_RDWR);
	s1 = mmap(NULL, pg, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	s2 = mmap(NULL, pg, PROT_READ, MAP_SHARED, fd, 0);
	pr = mmap(NULL, pg, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
	CHECK(s1 != MAP_FAILED && s2 != MAP_FAILED && pr != MAP_FAILED, "tres proyecciones del mismo archivo");
	{ volatile char t = pr[0] + s2[0]; (void)t; }   /* PTEs de lectura ya instaladas */
	memcpy(s1, "COMPARTIDO", 10);
	CHECK(!strncmp(s2, "COMPARTIDO", 10), "escritura en MAP_SHARED visible en otra proyeccion compartida");
	CHECK(!strncmp(pr, "COMPARTIDO", 10),
	      "...y TAMBIEN en MAP_PRIVATE mientras esa pagina no ha sido escrita (comparte el Page Cache)");
	slurp(path, buf, sizeof(buf));
	CHECK(!strncmp(buf, "COMPARTIDO", 10), "read() ve el cambio sin msync (mismo Page Cache)");
	msync(s1, pg, MS_SYNC);

	SECTION("Q3. MAP_PRIVATE: Copy-On-Write");
	memcpy(pr, "PRIVADO!!!", 10);
	CHECK(!strncmp(pr, "PRIVADO!!!", 10), "la escritura privada se ve en el proceso");
	CHECK(!strncmp(s2, "COMPARTIDO", 10), "pero NO en la proyeccion compartida");
	slurp(path, buf, sizeof(buf));
	CHECK(!strncmp(buf, "COMPARTIDO", 10), "ni en el archivo: la pagina fue copiada (COW) a memoria anonima");
	memcpy(s1, "SEGUNDO!!!", 10);
	CHECK(!strncmp(pr, "PRIVADO!!!", 10),
	      "tras el COW la copia privada queda DESACOPLADA de cambios posteriores del archivo");
	munmap(s1, pg); munmap(s2, pg); munmap(pr, pg);
	close(fd);

	SECTION("Q8. Descriptor O_RDONLY + PROT_WRITE");
	make_file(path, "ORIGINAL-ORIGINAL-ORIGINAL\n", 0644);
	ro = open(path, O_RDONLY);
	CHECK(try_mmap(ro, pg, PROT_READ | PROT_WRITE, MAP_SHARED) == EACCES,
	      "MAP_SHARED + PROT_WRITE sobre fd O_RDONLY -> EACCES (lo exige do_mmap)");
	p = mmap(NULL, pg, PROT_READ | PROT_WRITE, MAP_PRIVATE, ro, 0);
	CHECK(p != MAP_FAILED, "MAP_PRIVATE + PROT_WRITE sobre fd O_RDONLY -> PERMITIDO");
	if (p != MAP_FAILED) {
		memcpy(p, "FALSIFICADO", 11);
		CHECK(!strncmp(p, "FALSIFICADO", 11), "el proceso 've' datos alterados en su vista");
		slurp(path, buf, sizeof(buf));
		CHECK(!strncmp(buf, "ORIGINAL", 8), "el archivo en disco permanece intacto");
		munmap(p, pg);
	}
	p = mmap(NULL, pg, PROT_READ, MAP_SHARED, ro, 0);
	CHECK(p != MAP_FAILED && mprotect(p, pg, PROT_READ | PROT_WRITE) == -1 && errno == EACCES,
	      "mprotect(PROT_WRITE) en MAP_SHARED de fd O_RDONLY -> EACCES (VM_MAYWRITE ausente)");
	munmap(p, pg);
	p = mmap(NULL, pg, PROT_READ, MAP_PRIVATE, ro, 0);
	CHECK(p != MAP_FAILED && mprotect(p, pg, PROT_READ | PROT_WRITE) == 0,
	      "mprotect(PROT_WRITE) en MAP_PRIVATE de fd O_RDONLY -> permitido (VM_MAYWRITE presente)");
	munmap(p, pg);
	close(ro);
	return finish("test_semantica");
}
