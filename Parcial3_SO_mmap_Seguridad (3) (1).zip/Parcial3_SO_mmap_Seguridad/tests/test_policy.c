/**
 * @file test_policy.c
 * @brief Pruebas del motor de politica de MMGuard (ganchos security_mmap_file
 *        y security_file_mprotect). Simula intentos de acceso NO autorizado.
 *
 * Requiere: root y el modulo mmguard cargado.
 * Uso: ./test_policy [directorio_de_trabajo]   (por defecto /tmp/mmguard_test)
 */
#include "common.h"
#include <sys/types.h>

static char dir[256], secreto[300], libre[300], alias[300], symlk[300], renom[300];
static const char *CONTENIDO = "CONFIDENCIAL: salario=9.999.999; clave_bd=Sup3rS3cr3ta\n";

struct child_arg { const char *path; int uid; int expect_ok; int result; };

/* Hijo que baja privilegios a 'uid' e intenta mmap PROT_READ|MAP_SHARED. */
static void child_mmap_as(void *a)
{
	struct child_arg *c = a;
	int fd;

	if (setresgid(c->uid, c->uid, c->uid) || setresuid(c->uid, c->uid, c->uid))
		_exit(90);
	fd = open(c->path, O_RDONLY);
	if (fd < 0)
		_exit(91);
	_exit(try_mmap(fd, 4096, PROT_READ, MAP_SHARED) == 0 ? 0 : 1);
}

int main(int argc, char **argv)
{
	int fd, fd_libre, err;
	char buf[256];
	char *p;

	snprintf(dir, sizeof(dir), "%s", argc > 1 ? argv[1] : "/tmp/mmguard_test");
	mkdir(dir, 0755);
	snprintf(secreto, sizeof(secreto), "%s/secreto.txt", dir);
	snprintf(libre, sizeof(libre), "%s/libre.txt", dir);
	snprintf(alias, sizeof(alias), "%s/alias_hardlink.txt", dir);
	snprintf(symlk, sizeof(symlk), "%s/alias_symlink.txt", dir);
	snprintf(renom, sizeof(renom), "%s/renombrado.txt", dir);
	unlink(alias); unlink(symlk); unlink(renom);
	make_file(secreto, CONTENIDO, 0644);
	make_file(libre, "archivo sin proteccion\n", 0644);

	if (access("/proc/mmguard/policy", W_OK)) {
		fprintf(stderr, "mmguard no esta cargado o no es root\n");
		return 2;
	}
	write_str("/sys/module/mmguard/parameters/enforce", "1");
	policy("clear");
	policy("wx 0");

	SECTION("1. Regla 'asx': auditar, sin MAP_SHARED+PROT_WRITE, sin PROT_EXEC");
	CHECK(policy("add %s asx", secreto) == 0, "regla registrada en /proc/mmguard/policy");
	CHECK(policy("add %s zz", secreto) == -EINVAL, "letras invalidas rechazadas con EINVAL");
	CHECK(policy("add /no/existe a") == -ENOENT, "ruta inexistente rechazada con ENOENT");

	fd = open(secreto, O_RDWR);
	fd_libre = open(libre, O_RDWR);
	CHECK(fd >= 0 && fd_libre >= 0, "open(O_RDWR) permitido (DAC 0644 + root)");

	CHECK(try_mmap(fd, 4096, PROT_READ, MAP_SHARED) == 0,
	      "mmap(PROT_READ, MAP_SHARED) de lectura -> PERMITIDO");
	err = try_mmap(fd, 4096, PROT_READ | PROT_WRITE, MAP_SHARED);
	CHECK(err == EACCES, "mmap(PROT_READ|PROT_WRITE, MAP_SHARED) -> EACCES (obtuvo: %s)", strerror(err));
	err = try_mmap(fd_libre, 4096, PROT_READ | PROT_WRITE, MAP_SHARED);
	CHECK(err == 0, "control: mismo mmap sobre archivo NO protegido -> permitido");
	err = try_mmap(fd, 4096, PROT_READ | PROT_EXEC, MAP_PRIVATE);
	CHECK(err == EACCES, "mmap(PROT_EXEC) -> EACCES (el dato no puede volverse codigo)");

	SECTION("2. Evasion via mprotect(): mapear R y luego subir a R|W");
	p = mmap(NULL, 4096, PROT_READ, MAP_SHARED, fd, 0);
	CHECK(p != MAP_FAILED, "mmap(PROT_READ, MAP_SHARED) inicial");
	err = mprotect(p, 4096, PROT_READ | PROT_WRITE) ? errno : 0;
	CHECK(err == EACCES, "mprotect(R -> R|W) en mapeo compartido -> EACCES (obtuvo: %s)", strerror(err));
	err = mprotect(p, 4096, PROT_READ | PROT_EXEC) ? errno : 0;
	CHECK(err == EACCES, "mprotect(R -> R|X) -> EACCES");
	CHECK(memcmp(p, CONTENIDO, 12) == 0, "la lectura por puntero sigue funcionando: \"%.12s...\"", p);
	munmap(p, 4096);

	SECTION("3. MAP_PRIVATE + PROT_WRITE (Copy-On-Write) con regla 'asx'");
	p = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
	CHECK(p != MAP_FAILED, "MAP_PRIVATE escribible permitido: solo altera una copia COW");
	if (p != MAP_FAILED) {
		memcpy(p, "ALTERADO!!!!", 12);
		slurp(secreto, buf, sizeof(buf));
		CHECK(strncmp(buf, CONTENIDO, 12) == 0,
		      "el archivo en disco NO cambio (COW): \"%.12s\"", buf);
		munmap(p, 4096);
	}
	CHECK(policy("add %s asxp", secreto) == 0, "endurecer regla a 'asxp'");
	err = try_mmap(fd, 4096, PROT_READ | PROT_WRITE, MAP_PRIVATE);
	CHECK(err == EACCES, "MAP_PRIVATE + PROT_WRITE -> EACCES con bandera 'p'");

	SECTION("4. Evasion por nombre: hard link, symlink y rename");
	CHECK(link(secreto, alias) == 0, "hard link creado: %s", alias);
	CHECK(symlink(secreto, symlk) == 0, "symlink creado: %s", symlk);
	{
		int fa = open(alias, O_RDWR), fs = open(symlk, O_RDWR);

		CHECK(try_mmap(fa, 4096, PROT_READ | PROT_WRITE, MAP_SHARED) == EACCES,
		      "mmap RW via hard link -> EACCES (la regla es por inodo)");
		CHECK(try_mmap(fs, 4096, PROT_READ | PROT_WRITE, MAP_SHARED) == EACCES,
		      "mmap RW via symlink -> EACCES");
		close(fa); close(fs);
	}
	CHECK(rename(alias, renom) == 0, "rename del hard link");
	{
		int fr = open(renom, O_RDWR);

		CHECK(try_mmap(fr, 4096, PROT_READ | PROT_WRITE, MAP_SHARED) == EACCES,
		      "mmap RW tras rename -> EACCES");
		close(fr);
	}

	SECTION("5. Ruta via syscall directa (sin libc): la politica no depende de la libreria");
	{
		long r = syscall(SYS_mmap, NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

		int e = errno;

		CHECK(r == -1 && e == EACCES, "syscall(SYS_mmap) RW compartido -> EACCES");
		if (r != -1)
			munmap((void *)r, 4096);
	}

	SECTION("6. Regla 'd' (deny-all) con uid autorizado 1000");
	CHECK(policy("add %s ad 1000", secreto) == 0, "regla 'ad 1000'");
	CHECK(try_mmap(fd, 4096, PROT_READ, MAP_SHARED) == EACCES,
	      "root (uid 0) NO autorizado -> EACCES incluso en solo lectura");
	{
		struct child_arg a = { .path = secreto, .uid = 1000 };
		int st = run_in_child(child_mmap_as, &a);

		CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 0, "uid 1000 autorizado -> mmap permitido");
		a.uid = 1001;
		st = run_in_child(child_mmap_as, &a);
		CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 1, "uid 1001 -> mmap denegado");
	}
	{
		ssize_t n = slurp(secreto, buf, sizeof(buf));

		CHECK(n > 0, "read() clasico NO es interceptado (alcance: solo mmap/mprotect)");
		INFO("limitacion documentada: combinar con DAC/LSM para la ruta read()");
	}

	SECTION("7. Modo permissive (enforce=0): se registra pero no se bloquea");
	policy("add %s asx", secreto);
	CHECK(write_str("/sys/module/mmguard/parameters/enforce", "0") == 0, "enforce=0");
	CHECK(try_mmap(fd, 4096, PROT_READ | PROT_WRITE, MAP_SHARED) == 0,
	      "mmap RW compartido permitido en modo permissive");
	write_str("/sys/module/mmguard/parameters/enforce", "1");
	CHECK(try_mmap(fd, 4096, PROT_READ | PROT_WRITE, MAP_SHARED) == EACCES,
	      "enforce=1 de nuevo -> EACCES");

	SECTION("8. Auditoria de page faults (bandera 'a', kprobe filemap_fault)");
	{
		char sbuf[4096];
		size_t pg = 4096;
		int fbig;
		char path[300];
		volatile char sum = 0;
		long before = 0, after = 0;
		FILE *f;
		char line[256];

		snprintf(path, sizeof(path), "%s/grande.bin", dir);
		fbig = open(path, O_CREAT | O_TRUNC | O_RDWR, 0644);
		memset(sbuf, 'Z', sizeof(sbuf));
		for (int i = 0; i < 64; i++)
			if (write(fbig, sbuf, sizeof(sbuf)) < 0)
				break;
		/* Expulsar del page cache para forzar fallos "mayores" no siempre es
		 * posible en ramfs; aun asi el primer acceso por PTE vacia llama .fault */
		policy("add %s a", path);
		f = fopen("/proc/mmguard/stats", "r");
		while (f && fgets(line, sizeof(line), f))
			sscanf(line, "faults_audited %ld", &before);
		if (f) fclose(f);
		p = mmap(NULL, 64 * pg, PROT_READ, MAP_SHARED, fbig, 0);
		for (int i = 0; i < 64; i++)
			sum += p[i * pg];
		munmap(p, 64 * pg);
		f = fopen("/proc/mmguard/stats", "r");
		while (f && fgets(line, sizeof(line), f))
			sscanf(line, "faults_audited %ld", &after);
		if (f) fclose(f);
		CHECK(after > before, "page faults auditados: %ld para 64 paginas tocadas", after - before);
		INFO("con fault-around una sola llamada a filemap_map_pages instala hasta 16 PTE: eventos < paginas");
		close(fbig);
		(void)sum;
	}

	SECTION("9. Contadores en /proc/mmguard/stats");
	{
		FILE *f = fopen("/proc/mmguard/stats", "r");
		char line[256];
		long denied = 0, mpd = 0;

		while (f && fgets(line, sizeof(line), f)) {
			sscanf(line, "mmap_denied %ld", &denied);
			sscanf(line, "mprotect_denied %ld", &mpd);
		}
		if (f) fclose(f);
		CHECK(denied >= 8 && mpd >= 2, "mmap_denied=%ld mprotect_denied=%ld", denied, mpd);
	}

	close(fd);
	close(fd_libre);
	policy("clear");
	return finish("test_policy");
}
