/**
 * @file test_vault.c
 * @brief Pruebas de /dev/mmvault: cifrado transparente, aislamiento de paginas
 *        descifradas, integridad (HMAC) y control de acceso.
 *
 * Requiere: root y "insmod mmguard.ko vault_owner=0 debug_tamper=1".
 */
#include "common.h"
#include <stdint.h>
#include <sys/ioctl.h>
#include <sys/uio.h>
#include "../include/mmguard_uapi.h"

static const char SECRETO[] = "TOP-SECRET: llave_privada=4f9a1c77e2; tarjeta=4111-1111-1111-1111";
static long PG;

/* ---------- utilidades ---------- */
static uint64_t pfn_of(void *addr)
{
	uint64_t e = 0;
	int fd = open("/proc/self/pagemap", O_RDONLY);

	if (fd < 0)
		return 0;
	if (pread(fd, &e, 8, ((uintptr_t)addr / PG) * 8) != 8)
		e = 0;
	close(fd);
	return (e & (1ULL << 63)) ? (e & ((1ULL << 55) - 1)) : 0;
}

static int vmflags_have(void *addr, const char *flag)
{
	char line[512], want[64];
	unsigned long s, e;
	int in = 0, found = 0;
	FILE *f = fopen("/proc/self/smaps", "r");

	snprintf(want, sizeof(want), " %s ", flag);
	while (f && fgets(line, sizeof(line), f)) {
		if (sscanf(line, "%lx-%lx ", &s, &e) == 2 && strchr(line, '-') < strchr(line, ' '))
			in = ((uintptr_t)addr >= s && (uintptr_t)addr < e);
		if (in && !strncmp(line, "VmFlags:", 8)) {
			size_t l = strlen(line);

			if (line[l - 1] == '\n')
				line[l - 1] = ' ';
			found = strstr(line + 7, want) != NULL;
			break;
		}
	}
	if (f)
		fclose(f);
	return found;
}

/* ---------- hijos para pruebas con procesos separados ---------- */
static void *g_map;

static void child_touch_inherited(void *a)
{
	(void)a;
	/* Si VM_DONTCOPY funciona, la direccion no existe en el hijo -> SIGSEGV */
	volatile char c = *(volatile char *)g_map;
	(void)c;
}

static void child_unauthorized(void *a)
{
	int fd, r = 0;
	char buf[64];
	void *p;

	(void)a;
	if (setresgid(1000, 1000, 1000) || setresuid(1000, 1000, 1000))
		_exit(90);
	fd = open(MMV_DEVICE, O_RDWR);
	if (fd < 0)
		_exit(91);                         /* open debe funcionar (0666) */
	p = mmap(NULL, PG, PROT_READ, MAP_SHARED, fd, 0);
	if (p == MAP_FAILED && errno == EACCES)
		r |= 1;
	if (read(fd, buf, sizeof(buf)) < 0 && errno == EACCES)
		r |= 2;
	if (write(fd, "x", 1) < 0 && errno == EACCES)
		r |= 4;
	_exit(r);                              /* 7 = todo denegado */
}

struct peek { pid_t target; void *addr; };

static void child_process_vm_readv(void *a)
{
	struct peek *pk = a;
	char out[64];
	struct iovec l = { out, sizeof(out) }, r = { pk->addr, sizeof(out) };
	ssize_t n = process_vm_readv(pk->target, &l, 1, &r, 1, 0);

	_exit(n < 0 ? 1 : (memmem(out, sizeof(out), "TOP-SECRET", 10) ? 2 : 3));
}

int main(void)
{
	struct mmv_info info;
	struct mmv_cipher_req req;
	char *cbuf, buf[256];
	char *p, *q;
	int fd, st;

	PG = sysconf(_SC_PAGESIZE);
	fd = open(MMV_DEVICE, O_RDWR);
	if (fd < 0) {
		perror(MMV_DEVICE);
		return 2;
	}
	ioctl(fd, MMV_IOC_WIPE);

	SECTION("1. Cifrado en reposo (lo que veria un atacante con acceso al almacenamiento)");
	CHECK(pwrite(fd, SECRETO, sizeof(SECRETO), 0) == (ssize_t)sizeof(SECRETO),
	      "write() del secreto (%zu bytes) a la boveda", sizeof(SECRETO));
	memset(buf, 0, sizeof(buf));
	CHECK(pread(fd, buf, sizeof(buf), 0) == (ssize_t)sizeof(SECRETO) && !strcmp(buf, SECRETO),
	      "read() autorizado devuelve el texto plano");
	cbuf = malloc(PG);
	req.page = 0;
	req.buf = (uintptr_t)cbuf;
	CHECK(ioctl(fd, MMV_IOC_GET_CIPHER, &req) == 0, "exportar pagina 0 cifrada (version=%u)", req.version);
	CHECK(!memmem(cbuf, PG, "TOP-SECRET", 10) && !memmem(cbuf, PG, "4111", 4),
	      "el almacenamiento NO contiene el texto plano");
	INFO("primeros bytes cifrados: %02x %02x %02x %02x %02x %02x %02x %02x",
	     (unsigned char)cbuf[0], (unsigned char)cbuf[1], (unsigned char)cbuf[2],
	     (unsigned char)cbuf[3], (unsigned char)cbuf[4], (unsigned char)cbuf[5],
	     (unsigned char)cbuf[6], (unsigned char)cbuf[7]);

	SECTION("2. Proyeccion transparente: mmap() + descifrado en el page fault");
	ioctl(fd, MMV_IOC_INFO, &info);
	{
		uint64_t f0 = info.faults;

		p = mmap(NULL, 4 * PG, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		CHECK(p != MAP_FAILED, "mmap(4 paginas, RW, MAP_SHARED) autorizado");
		ioctl(fd, MMV_IOC_INFO, &info);
		CHECK(info.faults == f0, "tras mmap() no se descifro nada aun (paginacion por demanda)");
		CHECK(!strcmp(p, SECRETO), "lectura por puntero ve el texto plano: \"%.20s...\"", p);
		ioctl(fd, MMV_IOC_INFO, &info);
		CHECK(info.faults == f0 + 1, "exactamente 1 page fault atendido/descifrado");
	}
	CHECK(vmflags_have(p, "io") && vmflags_have(p, "dc") && vmflags_have(p, "dd"),
	      "VmFlags del VMA incluyen io (VM_IO), dc (VM_DONTCOPY), dd (VM_DONTDUMP)");
	CHECK(!vmflags_have(p, "me"), "VM_MAYEXEC retirado (no aparece 'me')");

	SECTION("3. Aislamiento entre proyecciones y frente a otros procesos");
	q = mmap(NULL, PG, PROT_READ, MAP_SHARED, fd, 0);
	CHECK(q != MAP_FAILED && !strcmp(q, SECRETO), "segunda proyeccion ve el mismo dato");
	{
		uint64_t a = pfn_of(p), b = pfn_of(q);

		CHECK(a && b && a != b, "marcos fisicos distintos: PFN 0x%llx vs 0x%llx (sin pagina en claro compartida)",
		      (unsigned long long)a, (unsigned long long)b);
	}
	CHECK(mprotect(q, PG, PROT_READ | PROT_EXEC) != 0, "mprotect(PROT_EXEC) imposible (errno=%s)", strerror(errno));
	g_map = p;
	st = run_in_child(child_touch_inherited, NULL);
	CHECK(WIFSIGNALED(st) && WTERMSIG(st) == SIGSEGV,
	      "fork(): el hijo NO hereda la proyeccion (SIGSEGV al tocarla)");
	{
		struct peek pk = { getpid(), p };

		st = run_in_child(child_process_vm_readv, &pk);
		CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 1,
		      "process_vm_readv() desde otro proceso root -> falla (VM_IO bloquea GUP)");
		{
			char *heap = strdup(SECRETO);

			pk.addr = heap;
			st = run_in_child(child_process_vm_readv, &pk);
			CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 2,
			      "control: el mismo secreto en heap normal SI se puede robar asi");
			free(heap);
		}
	}
	{
		int mfd = open("/proc/self/mem", O_RDONLY);
		ssize_t n = pread(mfd, buf, 32, (off_t)(uintptr_t)p);

		CHECK(n <= 0, "/proc/self/mem no expone la pagina descifrada (ret=%zd, %s)", n, strerror(errno));
		close(mfd);
	}
	st = run_in_child(child_unauthorized, NULL);
	CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 7,
	      "uid 1000 no autorizado: mmap/read/write -> EACCES (status=%d)", WEXITSTATUS(st));
	CHECK(mmap(NULL, PG, PROT_READ, MAP_PRIVATE, fd, 0) == MAP_FAILED && errno == EINVAL,
	      "MAP_PRIVATE rechazado (evita copias COW anonimas en claro)");
	CHECK(mmap(NULL, PG, PROT_READ | PROT_EXEC, MAP_SHARED, fd, 0) == MAP_FAILED && errno == EPERM,
	      "PROT_EXEC rechazado con EPERM");
	CHECK(mmap(NULL, 64 * PG, PROT_READ, MAP_SHARED, fd, 0) == MAP_FAILED,
	      "proyeccion mayor que la boveda rechazada");

	SECTION("4. Escritura por puntero -> re-cifrado al munmap()");
	{
		uint32_t v0;

		req.page = 0;
		ioctl(fd, MMV_IOC_GET_CIPHER, &req);
		v0 = req.version;
		memcpy(p, "MODIFICADO", 10);
		strcpy(p + 2 * PG, "dato nuevo en la pagina 2");
		munmap(q, PG);
		munmap(p, 4 * PG);
		memset(buf, 0, sizeof(buf));
		CHECK(pread(fd, buf, 64, 0) > 0 && !strncmp(buf, "MODIFICADO", 10), "read() ve el cambio persistido: \"%.24s\"", buf);
		CHECK(pread(fd, buf, 64, 2 * PG) > 0 && !strcmp(buf, "dato nuevo en la pagina 2"), "pagina 2 persistida");
		ioctl(fd, MMV_IOC_GET_CIPHER, &req);
		CHECK(req.version == v0 + 1, "version de la pagina 0: %u -> %u (IV nuevo, sin reutilizar nonce CTR)",
		      v0, req.version);
		CHECK(!memmem(cbuf, PG, "MODIFICADO", 10), "el nuevo texto cifrado tampoco contiene el claro");
		ioctl(fd, MMV_IOC_INFO, &info);
		CHECK(info.writebacks >= 2 && info.active_maps == 0, "writebacks=%llu, mapeos activos=%u",
		      (unsigned long long)info.writebacks, info.active_maps);
	}

	SECTION("5. Integridad: atacante altera 1 byte del almacenamiento cifrado");
	{
		uint32_t idx = 1;

		CHECK(pwrite(fd, "pagina uno", 10, PG) == 10, "escribir en la pagina 1");
		CHECK(ioctl(fd, MMV_IOC_DEBUG_CORRUPT, &idx) == 0, "bit-flip simulado en la pagina 1");
		p = mmap(NULL, 2 * PG, PROT_READ, MAP_SHARED, fd, 0);
		CHECK(p[0] == 'M', "pagina 0 (intacta) sigue legible");
		/* El hijo no hereda el mapeo (DONTCOPY): crea su propia proyeccion. */
		{
			pid_t pid = fork();

			if (pid == 0) {
				char *c = mmap(NULL, 2 * PG, PROT_READ, MAP_SHARED, fd, 0);
				volatile char x = c[PG];   /* debe producir SIGBUS */
				(void)x;
				_exit(0);
			}
			waitpid(pid, &st, 0);
		}
		CHECK(WIFSIGNALED(st) && WTERMSIG(st) == SIGBUS,
		      "acceso a la pagina alterada -> SIGBUS (nunca se entrega texto alterado)");
		CHECK(pread(fd, buf, 16, PG) < 0 && errno == EBADMSG,
		      "read() de la pagina alterada -> EBADMSG");
		ioctl(fd, MMV_IOC_INFO, &info);
		CHECK(info.tamper >= 2, "tamper detectado %llu veces (registrado en /proc/mmguard/log)",
		      (unsigned long long)info.tamper);
		munmap(p, 2 * PG);
	}

	ioctl(fd, MMV_IOC_WIPE);
	free(cbuf);
	close(fd);
	return finish("test_vault");
}
