# MMGuard — Seguridad de archivos `mmap()` en la capa del kernel

**Sistemas Operativos 2026-2 · Universidad EAFIT · Parcial práctico-teórico (25 %)**
Basado en el repositorio del curso `SO2026B/USOS/CapaKernel` (pasos 4 y 6).

El informe del parcial está en [`docs/INFORME_Parcial3_MMGuard.pdf`](docs/INFORME_Parcial3_MMGuard.pdf) y las salidas reales de las pruebas (90/90 verificaciones en 5.15 y 6.17, compilación contra 5.15, 6.8 y 6.17, benchmark y eBPF) en [`resultados/`](resultados/LEEME.md).

## Qué hace

| Componente | Archivo | Función |
|---|---|---|
| Motor de política | `kernel/mmguard_policy.c` | *kretprobes* sobre `security_mmap_file` y `security_file_mprotect`: niega con `-EACCES` según reglas por **inodo**; política global W^X; *kprobes* de auditoría sobre `filemap_fault` y `filemap_map_pages` |
| Bóveda cifrada | `kernel/mmguard_vault.c` | `/dev/mmvault`: AES-256-CTR + HMAC-SHA256 por página; descifrado en `vm_ops->fault` en páginas privadas por proyección; `VM_IO\|VM_DONTCOPY\|VM_DONTDUMP`; re-cifrado y borrado en `munmap` |
| Auditoría | `kernel/mmguard_audit.c` | anillo de 256 eventos seguro en contexto atómico + contadores |
| Interfaz | `kernel/mmguard_main.c` | `/proc/mmguard/{policy,stats,log}`, parámetro `enforce` |
| eBPF | `ebpf/mmap_audit.bt` | auditoría sin módulo: W+X, RW→RX, denegaciones, patrón Dirty COW |

## Requisitos

Linux x86_64 con `CONFIG_KPROBES`, `CONFIG_KRETPROBES`, `CONFIG_CRYPTO_CTR`, `CONFIG_CRYPTO_HMAC` (todos activos en Ubuntu/Debian).

| Kernel | Compila (`-Wall -Werror`) | Batería de pruebas en VM |
|---|---|---|
| Ubuntu 5.15.0-203-generic (22.04) | Sí | 90/90 |
| Ubuntu 6.8.0-147-generic (24.04) | Sí | No ejecutada |
| Ubuntu 6.17.0-42-generic (24.04 HWE) | Sí | 90/90 |

Otras versiones no se han probado. Los registros están en `resultados/compilacion_kernel_*.log` y `resultados/pruebas_codigo_final_kernel_*.log`.

```bash
sudo apt install build-essential linux-headers-$(uname -r)
# opcionales para mediciones: strace linux-tools-$(uname -r) bpftrace
```

> **Secure Boot:** si está activo, el kernel rechaza módulos sin firmar. Use una VM, desactívelo o firme el módulo (`kmodsign`/MOK).

## Compilar y ejecutar

```bash
make                              # modulo (kernel/mmguard.ko) + pruebas + benchmark
sudo ./scripts/run_all_tests.sh   # carga el modulo, ejecuta las 5 suites y lo descarga
sudo ./scripts/run_bench.sh       # overhead: sin modulo / 0 reglas / 64 reglas / auditoria total
sudo bpftrace ebpf/mmap_audit.bt -c "sh scripts/ebpf_workload.sh"
make clean
```

Uso manual:

```bash
sudo insmod kernel/mmguard.ko vault_owner=$(id -u)        # opcional: vault_pages=N debug_tamper=1
echo "add /srv/nomina.db asxp" | sudo tee /proc/mmguard/policy
echo "wx 1"                    | sudo tee /proc/mmguard/policy   # W^X global
echo 0 | sudo tee /sys/module/mmguard/parameters/enforce          # modo permissive
cat /proc/mmguard/policy /proc/mmguard/stats ; sudo cat /proc/mmguard/log
sudo rmmod mmguard
```

Letras de regla: `a` auditar · `s` sin `MAP_SHARED`+escritura · `p` sin `MAP_PRIVATE`+escritura · `x` sin `PROT_EXEC` · `d` negar todo salvo `[uid]`.

## Validación aislada (recomendada)

```bash
sudo apt install qemu-system-x86 busybox-static linux-image-6.17.0-42-generic linux-headers-6.17.0-42-generic
./qemu/run_in_qemu.sh /boot/vmlinuz-6.17.0-42-generic /usr/src/linux-headers-6.17.0-42-generic
# BPFTRACE=1 incluye la demo eBPF; la salida queda en resultados/qemu_run.log
```

La VM arranca con `oops=panic`: cualquier error del módulo detiene la corrida. Resultado de referencia: **90/90 verificaciones** en 5.15 y en 6.17, sin *oops*.

Para correr solo la batería de pruebas (sin eBPF ni benchmark) en otro kernel, por ejemplo 5.15:

```bash
MODE=tests KCC=gcc-11 ./qemu/run_in_qemu.sh /boot/vmlinuz-5.15.0-203-generic /usr/src/linux-headers-5.15.0-203-generic
```

## Estructura

```
include/mmguard_uapi.h   kernel/          tests/            bypass_userspace/
bench/bench_mmap.c       ebpf/            scripts/          qemu/run_in_qemu.sh
resultados/   salidas reales: pruebas 90/90 (5.15 y 6.17), compilación 5.15, 6.8 y 6.17, benchmark, eBPF (ver resultados/LEEME.md)
docs/         informe en PDF (INFORME_Parcial3_MMGuard.pdf) y diagramas (img/)
```
