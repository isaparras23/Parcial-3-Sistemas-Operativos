#!/bin/sh
# =============================================================================
# run_all_tests.sh - Bateria completa de pruebas de MMGuard
#
#   sudo ./scripts/run_all_tests.sh
#
# Variables opcionales:
#   TESTDIR=/ruta   directorio de trabajo para los archivos de prueba
#   RACE_SECS=N     duracion de cada variante de la PoC de carrera (def. 3)
#
# Escrito en sh POSIX para ejecutarse igual en Ubuntu/Debian y en la VM
# minima (busybox) de qemu/run_in_qemu.sh.
# =============================================================================
DIR=$(cd "$(dirname "$0")/.." && pwd)
TESTDIR=${TESTDIR:-/tmp/mmguard_test}
RACE_SECS=${RACE_SECS:-3}
KO="$DIR/kernel/mmguard.ko"
OUT="$DIR/resultados"
FAILS=0

say() { printf '\n\033[1;34m### %s\033[0m\n' "$*"; }
run() {
	"$@"
	rc=$?
	[ $rc -ne 0 ] && FAILS=$((FAILS + 1))
	return 0
}

if [ "$(id -u)" -ne 0 ]; then
	echo "Ejecute como root: sudo $0" >&2
	exit 1
fi
mkdir -p "$TESTDIR" "$OUT"

say "Kernel: $(uname -r)"

say "0. Semantica nativa del kernel (SIN MMGuard) - evidencia para Q1, Q2, Q3, Q8"
lsmod 2>/dev/null | grep -q '^mmguard' && rmmod mmguard
run "$DIR/tests/test_semantica" "$TESTDIR"

say "0b. Defensa en espacio de usuario (LD_PRELOAD) SIN MMGuard: se evade"
printf 'CONFIDENCIAL\n' > "$TESTDIR/secreto.txt"
if [ -x "$DIR/bypass_userspace/bypass_demo" ]; then
	LD_PRELOAD="$DIR/bypass_userspace/preload_guard.so" \
		"$DIR/bypass_userspace/bypass_demo" "$TESTDIR/secreto.txt"
fi

say "1. Carga del modulo"
insmod "$KO" vault_owner=0 vault_pages=16 debug_tamper=1 || { echo "insmod fallo"; exit 1; }
dmesg | grep mmguard | tail -4
ls -l /dev/mmvault /proc/mmguard/

say "2. Politica sobre mmap/mprotect (intentos de acceso no autorizado)"
run "$DIR/tests/test_policy" "$TESTDIR"

say "2b. La MISMA evasion LD_PRELOAD, ahora CON MMGuard (regla 's')"
echo "add $TESTDIR/secreto.txt as" > /proc/mmguard/policy
if [ -x "$DIR/bypass_userspace/bypass_demo" ]; then
	LD_PRELOAD="$DIR/bypass_userspace/preload_guard.so" \
		"$DIR/bypass_userspace/bypass_demo" "$TESTDIR/secreto.txt"
fi
echo clear > /proc/mmguard/policy

say "3. Boveda cifrada /dev/mmvault"
run "$DIR/tests/test_vault"

say "4. Politica W^X contra inyeccion de codigo"
run "$DIR/tests/test_wx"

say "5. PoC de carrera Dirty COW / MADV_DONTNEED (con MMGuard cargado)"
run "$DIR/tests/test_race" "$TESTDIR" "$RACE_SECS"

say "6. Estado final del modulo"
cat /proc/mmguard/stats
echo
tail -n 25 /proc/mmguard/log

cp /proc/mmguard/log "$OUT/audit_log.txt" 2>/dev/null
cp /proc/mmguard/stats "$OUT/stats.txt" 2>/dev/null

say "7. Descarga del modulo"
rmmod mmguard && echo "rmmod OK"
dmesg | grep -E 'mmguard|BUG|WARNING|Oops' | tail -6

if [ $FAILS -eq 0 ]; then
	printf '\n\033[1;32mRESULTADO GLOBAL: TODAS LAS SUITES PASARON\033[0m\n'
else
	printf '\n\033[1;31mRESULTADO GLOBAL: %d SUITE(S) CON FALLOS\033[0m\n' "$FAILS"
fi
exit $FAILS
