#!/bin/sh
# Carga de trabajo para demostrar ebpf/mmap_audit.bt:
#   sudo bpftrace ebpf/mmap_audit.bt -c "sh scripts/ebpf_workload.sh"
# Genera: proyecciones normales, W+X, RW->RX, denegaciones LSM y el patron Dirty COW.
DIR=$(cd "$(dirname "$0")/.." && pwd)
TESTDIR=${TESTDIR:-/tmp/mmguard_test}
mkdir -p "$TESTDIR"
printf 'CONFIDENCIAL\n' > "$TESTDIR/secreto.txt"
[ -w /proc/mmguard/policy ] && echo "add $TESTDIR/secreto.txt as" > /proc/mmguard/policy
"$DIR/tests/test_wx" >/dev/null 2>&1
"$DIR/tests/test_race" "$TESTDIR" 1 >/dev/null 2>&1
LD_PRELOAD="$DIR/bypass_userspace/preload_guard.so" \
	"$DIR/bypass_userspace/bypass_demo" "$TESTDIR/secreto.txt" >/dev/null 2>&1
[ -w /proc/mmguard/policy ] && echo clear > /proc/mmguard/policy
exit 0
