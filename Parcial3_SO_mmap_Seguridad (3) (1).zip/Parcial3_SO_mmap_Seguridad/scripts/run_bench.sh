#!/bin/sh
# =============================================================================
# run_bench.sh - Medicion del sobrecosto (overhead) de MMGuard
#
#   sudo ./scripts/run_bench.sh            (ITERS=20000 por defecto)
#
# Escenarios:
#   A) sin modulo                          -> linea base
#   B) modulo cargado, 0 reglas            -> costo fijo de las kretprobes
#   C) modulo + 64 reglas (el archivo medido NO tiene regla)
#                                          -> costo de la busqueda RCU lineal
#   D) C + regla 'a' sobre el archivo medido -> peor caso: auditar CADA #PF
# Ademas, si estan instalados: strace -c, perf stat y ftrace (function_graph).
# =============================================================================
DIR=$(cd "$(dirname "$0")/.." && pwd)
TESTDIR=${TESTDIR:-/tmp/mmguard_test}
ITERS=${ITERS:-20000}
OUT="$DIR/resultados"
CSV="$OUT/bench.csv"
B="$DIR/bench/bench_mmap"

# ftrace function_graph: duracion promedio de security_mmap_file (incluye las
# kretprobes cuando el modulo esta cargado). Uso: ftrace_mmap <etiqueta>
T=/sys/kernel/tracing
[ -d $T/events ] || T=/sys/kernel/debug/tracing
ftrace_mmap() {
	[ -w $T/current_tracer ] || return 0
	echo 0 > $T/tracing_on
	echo > $T/trace
	echo security_mmap_file > $T/set_graph_function
	echo function_graph > $T/current_tracer
	echo 1 > $T/tracing_on
	"$B" "$TESTDIR" ftrace 300 >/dev/null
	echo 0 > $T/tracing_on
	grep 'security_mmap_file \*/' $T/trace | sed 's/.*[|)] *[!#*@+$-]* *\([0-9.]*\) us.*/\1/' |
		awk -v l="$1" '$1+0>0 {s+=$1; n++} END {if (n) printf "ftrace,%s,security_mmap_file_us_promedio,%.2f,muestras=%d\n", l, s/n, n}' |
		tee -a "$OUT/ftrace_mmap.txt"
	echo nop > $T/current_tracer
	echo > $T/set_graph_function
}

[ "$(id -u)" -ne 0 ] && { echo "Ejecute como root" >&2; exit 1; }
mkdir -p "$TESTDIR" "$OUT"
lsmod 2>/dev/null | grep -q '^mmguard' && rmmod mmguard
: > "$CSV"

echo "== A) sin modulo"
"$B" "$TESTDIR" A_sin_modulo "$ITERS" | tee -a "$CSV"
: > "$OUT/ftrace_mmap.txt"
ftrace_mmap sin_modulo

echo "== B) modulo cargado, sin reglas"
insmod "$DIR/kernel/mmguard.ko" vault_owner=0
"$B" "$TESTDIR" B_modulo_0_reglas "$ITERS" | tee -a "$CSV"

echo "== C) modulo + 64 reglas (archivo medido sin regla)"
i=0
while [ $i -lt 64 ]; do
	: > "$TESTDIR/dummy_$i"
	echo "add $TESTDIR/dummy_$i sx" > /proc/mmguard/policy
	i=$((i + 1))
done
"$B" "$TESTDIR" C_64_reglas "$ITERS" | tee -a "$CSV"

echo "== D) 64 reglas + archivo medido con auditoria 'a' de cada page fault"
touch "$TESTDIR/bench.bin"
echo "add $TESTDIR/bench.bin a" > /proc/mmguard/policy
"$B" "$TESTDIR" D_auditoria_total "$ITERS" | tee -a "$CSV"
echo
cat /proc/mmguard/stats | grep -E 'check_ns|mmap_checked|faults_audited'
ftrace_mmap con_modulo_64_reglas

echo
echo "== Resumen (ns por operacion; menor es mejor)"
awk -F, '$1 ~ /^[A-D]_/ {v[$2","substr($1,1,1)]=$3; if (!($2 in seen)) {seen[$2]=1; ord[n++]=$2}}
END {
	printf "%-28s %11s %11s %11s %11s %8s %8s %8s\n", "metrica", "A", "B", "C", "D", "B/A", "C/A", "D/A";
	for (i = 0; i < n; i++) {
		k = ord[i]; a = v[k",A"];
		printf "%-28s %11s %11s %11s %11s", k, (a==""?"-":a), v[k",B"], v[k",C"], v[k",D"];
		if (a > 0) printf " %7.2fx %7.2fx %7.2fx\n", v[k",B"]/a, v[k",C"]/a, v[k",D"]/a; else printf " %8s %8s %8s\n", "-", "-", "-";
	}
}' "$CSV" | tee "$OUT/bench_resumen.txt"

# ---------------- Herramientas del sistema (si existen) --------------------
if command -v strace >/dev/null 2>&1; then
	echo; echo "== strace -c (llamadas al sistema del benchmark, escenario D: 64 reglas + auditoría)"
	strace -c -f -o "$OUT/strace_c.txt" "$B" "$TESTDIR" strace 2000 >/dev/null
	head -n 15 "$OUT/strace_c.txt"
fi
if command -v perf >/dev/null 2>&1; then
	echo; echo "== perf stat (page-faults, cambios de contexto)"
	perf stat -e page-faults,minor-faults,major-faults,context-switches,task-clock \
		"$B" "$TESTDIR" perf 5000 2>&1 >/dev/null | tee "$OUT/perf_stat.txt"
fi
echo clear > /proc/mmguard/policy
rmmod mmguard
rm -f "$TESTDIR"/dummy_*
echo; echo "Resultados en $OUT/"
