#!/bin/sh
# Descarga MMGuard (falla con EBUSY si hay procesos con /dev/mmvault abierto o proyectado).
if lsmod | grep -q '^mmguard'; then
	rmmod mmguard && echo "mmguard descargado"
	dmesg | grep mmguard | tail -2
else
	echo "mmguard no estaba cargado"
fi
