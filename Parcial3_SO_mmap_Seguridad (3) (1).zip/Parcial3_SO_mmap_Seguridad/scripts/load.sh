#!/bin/sh
# Carga MMGuard. Uso: sudo ./scripts/load.sh [vault_owner_uid]
# Por defecto la boveda pertenece al usuario que invoco sudo.
DIR=$(cd "$(dirname "$0")/.." && pwd)
OWNER=${1:-${SUDO_UID:-0}}
[ -f "$DIR/kernel/mmguard.ko" ] || make -C "$DIR/kernel" || exit 1
if lsmod | grep -q '^mmguard'; then
	echo "mmguard ya estaba cargado"
else
	insmod "$DIR/kernel/mmguard.ko" vault_owner="$OWNER" || exit 1
fi
dmesg | grep mmguard | tail -3
echo
echo "Interfaces:"
ls -l /dev/mmvault /proc/mmguard
echo
echo "Ejemplos:"
echo "  echo 'add /ruta/archivo asx' | sudo tee /proc/mmguard/policy"
echo "  cat /proc/mmguard/policy /proc/mmguard/stats; sudo cat /proc/mmguard/log"
